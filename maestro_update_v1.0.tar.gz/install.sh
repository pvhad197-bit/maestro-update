#!/bin/bash
set -e

echo "=== 1. CÀI ĐẶT CÔNG CỤ ĐIỀU PHỐI MẠNG ==="
pacman -Sy dnsmasq iptables --needed --noconfirm 2>/dev/null || apt-get install -y dnsmasq iptables 2>/dev/null || true

echo "=== 2. SAO CHÉP TẬP TIN DỊCH VỤ VÀ THỰC THI ==="
cp usr/local/bin/maestro-lan-arbiter.sh /usr/local/bin/
chmod +x /usr/local/bin/maestro-lan-arbiter.sh
cp etc/systemd/system/maestro-lan-arbiter.service /etc/systemd/system/

echo "=== 3. CẬP NHẬT PHIÊN BẢN OS LÊN CORE V1.0 ==="
find /var/www/html/ -type f -exec sed -i 's/2\.4\.2/Core v1.0/g' {} + 2>/dev/null || true
[ -f /var/www/html/version.txt ] && echo "Core v1.0" > /var/www/html/version.txt || true
[ -f /etc/maestro_version ] && echo "Core v1.0" > /etc/maestro_version || true

echo "=== 4. KÍCH HOẠT DỊCH VỤ ==="
systemctl daemon-reload
systemctl enable --now maestro-lan-arbiter.service

echo -e "\n[HOÀN TẤT] Cập nhật Maestro OS Core v1.0 thành công!"
exit 0
