#!/bin/bash
BASE_USB="/storage/usb_music"
BASE_NAS="/storage/nas_music"
LMS_DIR="/var/lib/squeezeboxserver/music"
NAS_CONF="/var/www/html/config/nas_creds.conf"

mkdir -p /storage/music "$LMS_DIR/internal_music"
mkdir -p "$BASE_USB" "$BASE_NAS" "$LMS_DIR/usb_music" "$LMS_DIR/nas_music"
chmod 777 "$BASE_USB" "$BASE_NAS" /storage/music 2>/dev/null

while true; do
  ROOT_DEV=$(findmnt -n -o SOURCE / 2>/dev/null | sed -E 's/p?[0-9]+$//')

  # A. TỰ ĐỘNG PHỤC HỒI KẾT NỐI NAS (KHI MẠNG ĐÃ SẴN SÀNG)
  if [ -s "$NAS_CONF" ]; then
    if ! mountpoint -q "$BASE_NAS"; then
      /usr/local/bin/maestro_nas_mounter.sh connect >/dev/null 2>&1
    fi
    if mountpoint -q "$BASE_NAS" && ! mountpoint -q "$LMS_DIR/nas_music"; then
      mount --bind "$BASE_NAS" "$LMS_DIR/nas_music" 2>/dev/null
      chmod 777 "$LMS_DIR/nas_music" 2>/dev/null
      curl -s -X POST http://127.0.0.1:9000/jsonrpc.js -d '{"id":1,"method":"slim.request","params":["",["rescan"]]}' 2>/dev/null
    fi
  fi

  # B. DUY TRÌ LIÊN KẾT BIND MOUNT CHO LMS
  if ! mountpoint -q "$LMS_DIR/usb_music"; then
    mount --bind "$BASE_USB" "$LMS_DIR/usb_music" 2>/dev/null
  fi
  if ! mountpoint -q "$LMS_DIR/internal_music"; then
    mount --bind /storage/music "$LMS_DIR/internal_music" 2>/dev/null
  fi

  # C. TỰ ĐỘNG MOUNT PHÂN VÙNG USB NGOÀI (ĐÃ FIX LỖI x20)
  for dev in $(lsblk -rnpo NAME,TYPE 2>/dev/null | awk '$2=="part" {print $1}' | grep -E "/dev/sd[a-z][0-9]+" | grep -v "$ROOT_DEV"); do
    [ ! -b "$dev" ] && continue

    if ! grep -qs "$dev " /proc/mounts; then
      FS_TYPE=$(lsblk -nro FSTYPE "$dev" 2>/dev/null)
      [ -z "$FS_TYPE" ] && continue

      RAW_LABEL=$(blkid -s LABEL -o value "$dev" 2>/dev/null || lsblk -dno LABEL "$dev" 2>/dev/null)
      LABEL=$(echo -e "$RAW_LABEL" | sed -e 's/\\x20/_/g' -e 's/[[:space:]]/_/g' -e 's/[^a-zA-Z0-9._-]//g')
      [ -z "$LABEL" ] && LABEL=$(lsblk -nro UUID "$dev" 2>/dev/null)
      [ -z "$LABEL" ] && LABEL=$(basename "$dev")

      TARGET_DIR="${BASE_USB}/${LABEL}"
      mkdir -p "$TARGET_DIR"

      case "$FS_TYPE" in
        ntfs)
          mount -t ntfs-3g -o rw,noatime,big_writes,utf8,umask=000 "$dev" "$TARGET_DIR" 2>/dev/null
          ;;
        exfat|vfat)
          mount -o rw,noatime,umask=000,iocharset=utf8 "$dev" "$TARGET_DIR" 2>/dev/null
          ;;
        *)
          mount -o rw,noatime "$dev" "$TARGET_DIR" 2>/dev/null
          ;;
      esac
    fi
  done

  # D. DỌN DẸP AN TOÀN KHI RÚT USB (TUYỆT ĐỐI KHÔNG DÙNG rm -rf)
  for dir in "$BASE_USB"/*; do
    if [ -d "$dir" ]; then
      if ! mountpoint -q "$dir"; then
        rmdir "$dir" 2>/dev/null
      fi
    fi
  done

  sleep 5
done
