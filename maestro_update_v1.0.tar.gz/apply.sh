#!/bin/bash
set -e

echo "=== 1. CÀI ĐẶT CÔNG CỤ ĐIỀU PHỐI MẠNG ==="
pacman -Sy dnsmasq iptables --needed --noconfirm 2>/dev/null || apt-get install -y dnsmasq iptables 2>/dev/null || true

echo "=== 2. SAO CHÉP TẬP TIN DỊCH VỤ VÀ THỰC THI ==="
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

if [ -f "$SCRIPT_DIR/usr/local/bin/maestro-lan-arbiter.sh" ]; then
    cp "$SCRIPT_DIR/usr/local/bin/maestro-lan-arbiter.sh" /usr/local/bin/
fi
chmod +x /usr/local/bin/maestro-lan-arbiter.sh

if [ -f "$SCRIPT_DIR/etc/systemd/system/maestro-lan-arbiter.service" ]; then
    cp "$SCRIPT_DIR/etc/systemd/system/maestro-lan-arbiter.service" /etc/systemd/system/
fi

echo "=== 3. CẬP NHẬT PHIÊN BẢN OS LÊN CORE V1.0 ==="
find /var/www/html/ -type f -exec sed -i 's/2\.4\.2/Core v1.0/g' {} + 2>/dev/null || true
[ -f /var/www/html/version.txt ] && echo "Core v1.0" > /var/www/html/version.txt || true
[ -f /etc/maestro_version ] && echo "Core v1.0" > /etc/maestro_version || true

echo "=== 4. KÍCH HOẠT DỊCH VỤ ==="
systemctl daemon-reload
systemctl enable --now maestro-lan-arbiter.service

echo "[*] Hoàn tất cập nhật Maestro OS Core v1.0!"
exit 0
