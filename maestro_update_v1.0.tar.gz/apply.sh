#!/bin/bash
set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo "=== 1. DỪNG VÀ VÔ HIỆU HÓA CÁC DỊCH VỤ XUNG ĐỘT ==="
systemctl stop usb-manager.service maestro-usb-automount.service 2>/dev/null || true
systemctl disable --now maestro-usb-automount.service 2>/dev/null || true
systemctl mask maestro-usb-automount.service 2>/dev/null || true
rm -f /usr/local/bin/maestro-usb-automount.sh* 2>/dev/null || true

echo "=== 2. CẬP NHẬT TRÌNH QUẢN LÝ LƯU TRỮ USB & NAS ==="
mkdir -p /opt/maestro
if [ -f "$SCRIPT_DIR/opt/maestro/usb_manager.sh" ]; then
    cp -f "$SCRIPT_DIR/opt/maestro/usb_manager.sh" /opt/maestro/usb_manager.sh
fi
chmod 755 /opt/maestro/usb_manager.sh

echo "=== 3. ĐỒNG BỘ PHÂN QUYỀN MÁY CHỦ NHẠC LMS ==="
chown -R nobody:nobody /var/lib/squeezeboxserver 2>/dev/null || true
chmod -R 775 /var/lib/squeezeboxserver 2>/dev/null || true

echo "=== 4. CẬP NHẬT PHIÊN BẢN OS LÊN CORE V1.0 ==="
find /var/www/html/ -type f -exec sed -i 's/2\.4\.2/Core v1.0/g' {} + 2>/dev/null || true
[ -f /var/www/html/version.txt ] && echo "Core v1.0" > /var/www/html/version.txt || true
[ -f /etc/maestro_version ] && echo "Core v1.0" > /etc/maestro_version || true

echo "=== 5. NẠP LẠI VÀ KHỞI ĐỘNG HỆ THỐNG DỊCH VỤ ==="
systemctl daemon-reload
systemctl enable usb-manager.service
systemctl restart usb-manager.service
systemctl restart squeezeboxserver.service 2>/dev/null || true
systemctl restart maestro-player.service 2>/dev/null || true

echo "[*] Hoàn tất cập nhật Maestro OS Core v1.0 (USB & NAS Storage Engine)!"
exit 0
