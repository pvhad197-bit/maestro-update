#!/usr/bin/env python3
import glob
import os
import re
import shutil
import subprocess

print("[1/5] Khoi tao trang thai /etc/maestro_harmonic_mode...")
mode_file = "/etc/maestro_harmonic_mode"
cur_mode = "off"
if os.path.exists(mode_file):
    with open(mode_file, "r", encoding="utf-8", errors="ignore") as f:
        val = f.read().strip()
        if val == "subtle":
            val = "warm"
        if val in ("off", "warm", "sweet", "300b", "tape"):
            cur_mode = val
with open(mode_file, "w", encoding="utf-8", newline="\n") as f:
    f.write(cur_mode + "\n")
os.chmod(mode_file, 0o666)

print("[2/5] Cap nhat kich ban xu ly am thanh /usr/local/sbin/432squeeze...")
sq_path = "/usr/local/sbin/432squeeze"
if os.path.exists(sq_path):
    if not os.path.exists(sq_path + ".bak_v1.0"):
        shutil.copy2(sq_path, sq_path + ".bak_v1.0")
    with open(sq_path, "r", encoding="utf-8", errors="ignore") as f:
        s = f.read()

    harmonic_block = """HARMONIC_MODE=$(cat /etc/maestro_harmonic_mode 2>/dev/null | tr -d "[:space:]")
[ -z "$HARMONIC_MODE" ] && HARMONIC_MODE="off"
case "$HARMONIC_MODE" in
    warm)   V_CTRL="0.16 0.0";  DRY_AMP="1.85"; WET_AMP="0.0"; DRY_G="0.975"; WET_G="0.025" ;;
    sweet)  V_CTRL="0.22 0.04"; DRY_AMP="1.85"; WET_AMP="0.0"; DRY_G="0.968"; WET_G="0.032" ;;
    300b)   V_CTRL="0.28 0.06"; DRY_AMP="1.90"; WET_AMP="0.0"; DRY_G="0.962"; WET_G="0.038" ;;
    tape)   V_CTRL="0.35 0.12"; DRY_AMP="1.90"; WET_AMP="0.0"; DRY_G="0.955"; WET_G="0.045" ;;
    *)      V_CTRL="" ;;
esac
if [ -n "$V_CTRL" ]; then
    cat <<EOF > /etc/asound.conf
pcm.maestro_analog {
    type plug
    slave {
        pcm "maestro_parallel_dsp"
        channels 4
        format FLOAT
    }
    ttable.0.0 1.0
    ttable.1.1 1.0
    ttable.0.2 1.0
    ttable.1.3 1.0
}

pcm.maestro_parallel_dsp {
    type ladspa
    slave.pcm "maestro_parallel_mix"
    path "/usr/lib/ladspa"
    plugins [
        { label amp          id 1181 policy none input { bindings { 0 "Input" } controls [ ${DRY_AMP} ] } output { bindings { 0 "Output" } } }
        { label amp          id 1181 policy none input { bindings { 1 "Input" } controls [ ${DRY_AMP} ] } output { bindings { 1 "Output" } } }
        { label butthigh_iir id 1904 policy none input { bindings { 2 "Input" } controls [ 160 0.50 ] } output { bindings { 2 "Output" } } }
        { label valve        id 1209 policy none input { bindings { 2 "Input" } controls [ ${V_CTRL} ] } output { bindings { 2 "Output" } } }
        { label buttlow_iir  id 1903 policy none input { bindings { 2 "Input" } controls [ 11000 0.50 ] } output { bindings { 2 "Output" } } }
        { label amp          id 1181 policy none input { bindings { 2 "Input" } controls [ ${WET_AMP} ] } output { bindings { 2 "Output" } } }
        { label butthigh_iir id 1904 policy none input { bindings { 3 "Input" } controls [ 160 0.50 ] } output { bindings { 3 "Output" } } }
        { label valve        id 1209 policy none input { bindings { 3 "Input" } controls [ ${V_CTRL} ] } output { bindings { 3 "Output" } } }
        { label buttlow_iir  id 1903 policy none input { bindings { 3 "Input" } controls [ 11000 0.50 ] } output { bindings { 3 "Output" } } }
        { label amp          id 1181 policy none input { bindings { 3 "Input" } controls [ ${WET_AMP} ] } output { bindings { 3 "Output" } } }
    ]
}

pcm.maestro_parallel_mix {
    type plug
    slave {
        pcm "plughw:CARD=${CARD_ID},DEV=0"
        channels 2
    }
    ttable.0.0 ${DRY_G}
    ttable.2.0 ${WET_G}
    ttable.1.1 ${DRY_G}
    ttable.3.1 ${WET_G}
}
EOF
    DEVICE_SOX="maestro_analog"
else
    DEVICE_SOX="hw:CARD=${CARD_ID},DEV=0"
fi
"""

    if "HARMONIC_MODE=" in s:
        start = s.find("HARMONIC_MODE=")
        end = s.find('if [ "$HARMONIC_MODE" = "off" ]')
        if end == -1:
            end = s.find('if [ "$FROM" = "$TO" ]')
        if start != -1 and end != -1:
            s = s[:start] + harmonic_block + s[end:]
    else:
        target = 'if [ "$FROM" = "$TO" ]'
        if target in s:
            s = s.replace(target, harmonic_block + 'if [ "$HARMONIC_MODE" = "off" ] && [ "$FROM" = "$TO" ]', 1)

    with open(sq_path, "w", encoding="utf-8", newline="\n") as f:
        f.write(s)
    os.chmod(sq_path, 0o755)

restart_sh = "/usr/local/bin/maestro-restart-player.sh"
if os.path.exists(restart_sh):
    with open(restart_sh, "w", encoding="utf-8", newline="\n") as f:
        f.write("#!/bin/bash\nsystemctl restart maestro-player.service 2>/dev/null || true\n")
    os.chmod(restart_sh, 0o755)

print("[3/5] Cap nhat giao dien Smarty template hw.tpl...")
tpls = glob.glob("/var/www/**/hw.tpl", recursive=True)
harmonic_html = """                    <div class="form-group row align-items-center mb-3" id="maestro-harmonic-row">
                        <label for="harmonic_mode" class="col-sm-4 col-form-label font-weight-bold text-sm-right">Additional Harmonics:</label>
                        <div class="col-sm-8">
                            <select name="harmonic_mode" id="harmonic_mode" class="form-control">
                                <option value="off" {if $current_harmonic eq 'off' || $current_harmonic eq ''}selected{/if}>Off - Direct Output (Bit-Perfect / Pure)</option>
                                <option value="warm" {if $current_harmonic eq 'warm'}selected{/if}>Reference</option>
                                <option value="sweet" {if $current_harmonic eq 'sweet'}selected{/if}>Natural Sweet Spot</option>
                                <option value="300b" {if $current_harmonic eq '300b'}selected{/if}>Tube Harmonic</option>
                                <option value="tape" {if $current_harmonic eq 'tape'}selected{/if}>Analog/ Reel-to-Reel/ Tape</option>
                            </select>
                        </div>
                    </div>"""

for tpl_path in tpls:
    if not os.path.exists(tpl_path + ".bak_v1.0"):
        shutil.copy2(tpl_path, tpl_path + ".bak_v1.0")
    with open(tpl_path, "r", encoding="utf-8", errors="ignore") as f:
        t = f.read()
    t = re.sub(r'\s*<div[^>]*id="maestro-harmonic-row"[\s\S]*?</div>\s*</div>', "", t)
    if 'name="harmonic_mode"' not in t:
        m = re.search(r'(<select[^>]*name="sox_filter"[\s\S]*?</div>\s*</div>)', t)
        if m:
            t = t[:m.end()] + "\n" + harmonic_html + t[m.end():]
    with open(tpl_path, "w", encoding="utf-8", newline="\n") as f:
        f.write(t)

print("[4/5] Cap nhat xu ly luu cau hinh va dong bo ngon ngu EN/VI trong /var/www/html/hw.php...")
php_path = "/var/www/html/hw.php"
if os.path.exists(php_path):
    if not os.path.exists(php_path + ".bak_v1.0"):
        shutil.copy2(php_path, php_path + ".bak_v1.0")
    with open(php_path, "r", encoding="utf-8", errors="ignore") as f:
        p_code = f.read()

    p_code = re.sub(r"// === MAESTRO_HARMONIC_POST_START ===.*?// === MAESTRO_HARMONIC_POST_END ===\n?", "", p_code, flags=re.S)
    post_snippet = """// === MAESTRO_HARMONIC_POST_START ===
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['harmonic_mode'])) {
    $hm = trim($_POST['harmonic_mode']);
    if ($hm === 'subtle') $hm = 'warm';
    if (!in_array($hm, ['off', 'warm', 'sweet', '300b', 'tape'])) $hm = 'off';
    @file_put_contents('/etc/maestro_harmonic_mode', $hm . "\n");
    @chmod('/etc/maestro_harmonic_mode', 0666);
}
// === MAESTRO_HARMONIC_POST_END ===
"""
    if "<?php" in p_code:
        p_code = p_code.replace("<?php", "<?php\n" + post_snippet, 1)

    p_code = re.sub(r"// === MAESTRO_HARMONIC_ASSIGN_START ===.*?// === MAESTRO_HARMONIC_ASSIGN_END ===\n?", "", p_code, flags=re.S)
    assign_snippet = """// === MAESTRO_HARMONIC_ASSIGN_START ===
$current_harmonic = file_exists('/etc/maestro_harmonic_mode') ? trim(file_get_contents('/etc/maestro_harmonic_mode')) : 'off';
if ($current_harmonic === 'subtle') $current_harmonic = 'warm';
$smarty->assign('current_harmonic', $current_harmonic);
// === MAESTRO_HARMONIC_ASSIGN_END ===
"""
    disp_match = re.search(r'\$smarty->display\s*\([^;]+\)\s*;', p_code)
    if disp_match:
        p_code = p_code[:disp_match.start()] + assign_snippet + p_code[disp_match.start():]

    p_code = re.sub(r"// === MAESTRO_HARMONIC_VI_START ===.*?// === MAESTRO_HARMONIC_VI_END ===\n?", "", p_code, flags=re.S)
    vi_snippet = """// === MAESTRO_HARMONIC_VI_START ===
    $is_vi = false;
    if (isset($_GET['lang'])) {
        $is_vi = (strtolower(trim($_GET['lang'])) === 'vi');
    } elseif (strpos($html, 'Hardware Configuration') !== false) {
        $is_vi = false;
    } elseif (strpos($html, 'Cấu hình Phần cứng') !== false) {
        $is_vi = true;
    }
    if ($is_vi) {
        $vi_map = [
            '>Additional Harmonics:<' => '>Hài âm bổ sung (Sóng hài bậc 2):<',
            '>Additional harmonics:<' => '>Hài âm bổ sung (Sóng hài bậc 2):<',
            '>Off - Direct Output (Bit-Perfect / Pure)<' => '>Tắt - Xuất thẳng trực tiếp (Bit-Perfect / Nguyên bản)<',
            '>Reference<' => '>Tham chiếu (Hài âm ấm nhẹ)<',
            '>Natural Sweet Spot<' => '>Điểm ngọt tự nhiên (Cân bằng, nổi khối)<',
            '>Tube Harmonic<' => '>Hài âm đèn 300B (Mượt mà, nhạc tính)<',
            '>Analog/ Reel-to-Reel/ Tape<' => '>Analog / Băng cối (Dày dặn, mộc mạc)<',
            '>Analog / Reel-to-Reel / Tape<' => '>Analog / Băng cối (Dày dặn, mộc mạc)<',
            '>Playback Guide<' => '>Hướng dẫn phát nhạc<',
        ];
        $html = strtr($html, $vi_map);
        $html = preg_replace(
            '/\\*\\s*For\\s*<b>DSD<\\/b>.*?<\\/p>/is',
            '* Đối với <b>DSD</b> (chỉ dùng với USB DAC): Chọn <b>Native/DoP</b> (Chế độ xuất DSD), <b>Native</b> (Tần số lấy mẫu tối đa), <b>Direct Bit-Perfect</b> (Tần số điều chỉnh và Kiến trúc bộ lọc DSP), và <b>Tắt - Xuất thẳng trực tiếp</b> (Hài âm bổ sung).</p>',
            $html
        );
        $html = preg_replace(
            '/\\*\\s*For\\s*<b>PCM<\\/b>.*?<\\/p>/is',
            '* Đối với <b>PCM</b>: Chọn <b>Disable DSD</b> (Chế độ xuất DSD) khi sử dụng các Tần số nghe thay thế khác 440Hz.</p>',
            $html
        );
    } else {
        $en_map = [
            '>Hài âm bổ sung (Sóng hài bậc 2):<' => '>Additional Harmonics:<',
            '>Tắt - Xuất thẳng trực tiếp (Bit-Perfect / Nguyên bản)<' => '>Off - Direct Output (Bit-Perfect / Pure)<',
            '>Tham chiếu (Hài âm ấm nhẹ)<' => '>Reference<',
            '>Điểm ngọt tự nhiên (Cân bằng, nổi khối)<' => '>Natural Sweet Spot<',
            '>Hài âm đèn 300B (Mượt mà, nhạc tính)<' => '>Tube Harmonic<',
            '>Hài âm đèn điện tử (Mượt mà, nhạc tính)<' => '>Tube Harmonic<',
            '>Analog / Băng cối (Dày dặn, mộc mạc)<' => '>Analog/ Reel-to-Reel/ Tape<',
            '>Hướng dẫn phát nhạc<' => '>Playback Guide<',
        ];
        $html = strtr($html, $en_map);
        $html = preg_replace(
            '/\\*\\s*Đối với\\s*<b>DSD<\\/b>.*?<\\/p>/is',
            '* For <b>DSD</b> (USB DAC only): Select <b>Native/DoP</b> (DSD Output Mode), <b>Native</b> (Max Sample Rate), <b>Direct Bit-Perfect</b> (Tuning Frequency and DSP Filter Architecture), and <b>Off - Direct Output</b> (Additional Harmonics).</p>',
            $html
        );
        $html = preg_replace(
            '/\\*\\s*Đối với\\s*<b>PCM<\\/b>.*?<\\/p>/is',
            '* For <b>PCM</b>: Select <b>Disable DSD</b> (DSD Output Mode) when using alternative Tuning Frequencies other than 440Hz.</p>',
            $html
        );
    }
    // === MAESTRO_HARMONIC_VI_END ==="""

    disp_match2 = re.search(r'\$smarty->display\s*\(([^;]+)\)\s*;', p_code)
    if disp_match2:
        tpl_arg = disp_match2.group(1)
        replacement = f"$html = $smarty->fetch({tpl_arg});\n{vi_snippet}\n    echo $html;"
        p_code = p_code[:disp_match2.start()] + replacement + p_code[disp_match2.end():]

    with open(php_path, "w", encoding="utf-8", newline="\n") as f:
        f.write(p_code)
    subprocess.run(["php", "-l", php_path], check=False)

print("[5/5] Xoa bo nho dem Smarty...")
for cdir in glob.glob("/var/www/**/templates_c", recursive=True):
    for item in os.listdir(cdir):
        ipath = os.path.join(cdir, item)
        try:
            if os.path.isdir(ipath):
                shutil.rmtree(ipath)
            else:
                os.remove(ipath)
        except Exception:
            pass
print("[OK] Hoan tat cap nhat module Hai am bo sung v1.1!")
