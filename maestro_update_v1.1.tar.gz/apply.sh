#!/bin/bash
set -e

echo "=== 1. KIỂM TRA VÀ CÀI ĐẶT PLUGIN XỬ LÝ HÀI ÂM LADSPA ==="
pacman -Sy swh-plugins ladspa --needed --noconfirm 2>/dev/null || apt-get install -y swh-plugins ladspa-sdk 2>/dev/null || true

echo "=== 2. ÁP DỤNG BẢN CẬP NHẬT HÀI ÂM BỔ SUNG (PARALLEL DRY/WET 32-BIT FLOAT) ==="
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
python3 "$SCRIPT_DIR/scripts/patch_harmonic_v1.1.py"

echo "=== 3. CẬP NHẬT PHIÊN BẢN OS LÊN CORE V1.1 ==="
find /var/www/html/ -type f -exec sed -i 's/Core v1\.0/Core v1.1/g; s/2\.4\.2/Core v1.1/g' {} + 2>/dev/null || true
[ -f /var/www/html/version.txt ] && echo "Core v1.1" > /var/www/html/version.txt || true
[ -f /etc/maestro_version ] && echo "Core v1.1" > /etc/maestro_version || true

echo "=== 4. KHỞI ĐỘNG LẠI DỊCH VỤ ÂM THANH ==="
systemctl daemon-reload
systemctl restart maestro-player.service 2>/dev/null || true

echo "[*] Hoàn tất cập nhật Maestro OS Core v1.1 (Additional Harmonics)!"
exit 0
