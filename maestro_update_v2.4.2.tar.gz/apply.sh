#!/bin/bash
echo "=== ĐANG THỰC THI BẢN VÁ CHO MAESTRO OS v2.4.2 ==="

# 1. Tạo thư mục nhạc nội bộ và liên kết vào Lyrion
mkdir -p /storage/music /var/lib/squeezeboxserver/music/internal_music
chmod -R 777 /storage/music /var/lib/squeezeboxserver/music/internal_music 2>/dev/null

umount -lf /var/lib/squeezeboxserver/music/internal_music 2>/dev/null || true
mount --bind /storage/music /var/lib/squeezeboxserver/music/internal_music
chmod 777 /var/lib/squeezeboxserver/music/internal_music 2>/dev/null

# 2. Đổi đường dẫn Samba [music] sang /storage/music
if [ -f /etc/samba/smb.conf ]; then
    cp -n /etc/samba/smb.conf /etc/samba/smb.conf.bak 2>/dev/null
    sed -i 's|path = /var/lib/squeezeboxserver/music$|path = /storage/music|g' /etc/samba/smb.conf
    sed -i 's|path = /var/lib/squeezeboxserver/music/|path = /storage/music|g' /etc/samba/smb.conf
    systemctl restart smb nmb 2>/dev/null || systemctl restart smbd nmbd 2>/dev/null
fi

# 3. Nhúng duy trì liên kết vào usb_manager.sh
if [ -f /opt/maestro/usb_manager.sh ] && ! grep -q "internal_music" /opt/maestro/usb_manager.sh; then
    sed -i '/while true; do/a \    if ! mountpoint -q "/var/lib/squeezeboxserver/music/internal_music"; then\n        mount --bind /storage/music "/var/lib/squeezeboxserver/music/internal_music" 2>/dev/null\n        chmod 777 "/var/lib/squeezeboxserver/music/internal_music" 2>/dev/null\n    fi' /opt/maestro/usb_manager.sh
    systemctl restart usb-manager.service 2>/dev/null
fi

# Báo Lyrion quét lại kho nhạc
curl -s -X POST http://127.0.0.1:9000/jsonrpc.js -d '{"id":1,"method":"slim.request","params":["",["rescan"]]}' >/dev/null 2>&1

exit 0
