#!/bin/bash
echo "=== BẮT ĐẦU CẬP NHẬT MAESTRO OS v2.4.2 ==="

# 1. TẠO THƯ MỤC NHẠC TRÊN Ổ 106GB VÀ LIÊN KẾT VÀO LYRION
mkdir -p /storage/music
chmod -R 777 /storage/music 2>/dev/null

mkdir -p /var/lib/squeezeboxserver/music/internal_music
chmod 777 /var/lib/squeezeboxserver/music/internal_music 2>/dev/null

umount -lf /var/lib/squeezeboxserver/music/internal_music 2>/dev/null || true
mount --bind /storage/music /var/lib/squeezeboxserver/music/internal_music
chmod 777 /var/lib/squeezeboxserver/music/internal_music 2>/dev/null

# 2. CẬP NHẬT CẤU HÌNH SAMBA TRỎ SHARE [music] VÀO /storage/music
if [ -f /etc/samba/smb.conf ]; then
    cp -n /etc/samba/smb.conf /etc/samba/smb.conf.bak 2>/dev/null
    sed -i 's|path = /var/lib/squeezeboxserver/music$|path = /storage/music|g' /etc/samba/smb.conf
    sed -i 's|path = /var/lib/squeezeboxserver/music/|path = /storage/music|g' /etc/samba/smb.conf
    systemctl restart smb nmb 2>/dev/null || systemctl restart smbd nmbd 2>/dev/null
fi

# 3. NHÚNG TỰ ĐỘNG DUY TRÌ LIÊN KẾT VÀO /opt/maestro/usb_manager.sh
if [ -f /opt/maestro/usb_manager.sh ] && ! grep -q "internal_music" /opt/maestro/usb_manager.sh; then
    sed -i '/while true; do/a \    if ! mountpoint -q "/var/lib/squeezeboxserver/music/internal_music"; then\n        mount --bind /storage/music "/var/lib/squeezeboxserver/music/internal_music" 2>/dev/null\n        chmod 777 "/var/lib/squeezeboxserver/music/internal_music" 2>/dev/null\n    fi' /opt/maestro/usb_manager.sh
    systemctl restart usb-manager.service 2>/dev/null
fi

# 4. TỰ ĐỘNG QUÉT VÀ THAY ĐỔI ĐÍCH DANH PHIÊN BẢN TRÊN WEB MAESTRO
grep -rl "Maestro OS v2.4.1" /var/www/html/ /etc/ /opt/ 2>/dev/null | while read -r file; do
    sed -i 's/Maestro OS v2.4.1/Maestro OS v2.4.2/g' "$file"
done
grep -rl "v2.4.1" /var/www/html/version* /opt/maestro/ 2>/dev/null | while read -r file; do
    sed -i 's/v2.4.1/v2.4.2/g' "$file"
done

# Báo Lyrion quét cập nhật bài hát
curl -s -X POST http://127.0.0.1:9000/jsonrpc.js -d '{"id":1,"method":"slim.request","params":["",["rescan"]]}' >/dev/null 2>&1

echo "=== ĐÃ NÂNG CẤP THÀNH CÔNG LÊN MAESTRO OS v2.4.2 ==="
