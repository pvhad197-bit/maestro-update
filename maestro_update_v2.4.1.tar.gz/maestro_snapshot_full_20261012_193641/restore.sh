#!/bin/bash
set -e
BASE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo "-> Äang khÃ´i phá»¥c há»‡ thá»‘ng Maestro tá»« báº£n sao lÆ°u..."

# KhÃ´i phá»¥c Web
cp -rp "${BASE_DIR}/web/"* /var/www/html/ 2>/dev/null || true
rm -rf /var/www/html/templates_c/* 2>/dev/null || true
chown -R www-data:www-data /var/www/html 2>/dev/null || chown -R apache:apache /var/www/html 2>/dev/null || true

# KhÃ´i phá»¥c Bin/Sbin
[ -f "${BASE_DIR}/bin/432squeeze" ] && cp -p "${BASE_DIR}/bin/432squeeze" /usr/local/sbin/432squeeze && chmod 755 /usr/local/sbin/432squeeze
cp -p "${BASE_DIR}/bin/maestro_apply_"* /usr/local/bin/ 2>/dev/null || true
chmod 755 /usr/local/bin/maestro_apply_*.sh 2>/dev/null || true

# KhÃ´i phá»¥c Systemd
cp -p "${BASE_DIR}/systemd/"* /etc/systemd/system/ 2>/dev/null || true

# KhÃ´i phá»¥c Cáº¥u hÃ¬nh
cp -p "${BASE_DIR}/configs/"* /etc/ 2>/dev/null || true
chmod 666 /etc/maestro_* 2>/dev/null || true

# KhÃ´i phá»¥c Sudoers & Modprobe
[ -d "${BASE_DIR}/sudoers" ] && cp -p "${BASE_DIR}/sudoers/"* /etc/sudoers.d/ 2>/dev/null || true
chmod 440 /etc/sudoers.d/maestro_net 2>/dev/null || true
[ -d "${BASE_DIR}/modprobe" ] && cp -p "${BASE_DIR}/modprobe/"* /etc/modprobe.d/ 2>/dev/null || true

systemctl daemon-reload
pkill -9 -f squeezelite 2>/dev/null || true
pkill -9 -f sox 2>/dev/null || true
systemctl restart maestro-player 2>/dev/null || true

echo "-> KHÃ”I PHá»¤C HOÃ€N Táº¤T VÃ€ Dá»ŠCH Vá»¤ ÄÃƒ CHáº Y Láº I BÃŒNH THÆ¯á»œNG!"
