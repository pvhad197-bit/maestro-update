#!/usr/bin/env bash
set -e
echo "[+] Đang áp dụng bản vá Maestro OS v2.4..."

# Ghi đè file mới
cp -f files/bin/maestro_apply_audio.sh /usr/local/bin/
cp -f files/web/hw.php /var/www/html/
cp -f files/tpl/hw.tpl /var/www/html/templates/

# Phân quyền chuẩn
chmod +x /usr/local/bin/maestro_apply_audio.sh
chmod 644 /var/www/html/hw.php
chmod 644 /var/www/html/templates/hw.tpl

# Khởi tạo file nhớ buffer và cấp quyền ghi cho Web UI
if [ ! -f /etc/maestro_buffer_mode ]; then
    echo "balanced" > /etc/maestro_buffer_mode
fi
chmod 666 /etc/maestro_buffer_mode

# Xóa sạch cache template của Smarty
rm -rf /var/www/html/templates_c/*

# Nạp lại systemd
systemctl daemon-reload

echo "[+] Cập nhật thành công Maestro OS v2.4 (DSD Auto-Detect + ALSA Buffer v2.4)!"
