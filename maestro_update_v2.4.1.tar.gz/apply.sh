#!/bin/bash
set -e
BASE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo "[+] Bắt đầu áp dụng bản nâng cấp Maestro OS v2.4.1..."

# 1. Khôi phục/Cập nhật Web
if [ -d "${BASE_DIR}/web" ]; then
    echo "  -> Cập nhật giao diện Web..."
    WEB_PATH="/var/www/html"
    [ ! -d "$WEB_PATH" ] && [ -d "/srv/http" ] && WEB_PATH="/srv/http"
    cp -rp "${BASE_DIR}/web/"* "$WEB_PATH/" 2>/dev/null || true
    rm -rf "$WEB_PATH/templates_c/"* 2>/dev/null || true
    chown -R www-data:www-data "$WEB_PATH" 2>/dev/null || chown -R http:http "$WEB_PATH" 2>/dev/null || chown -R apache:apache "$WEB_PATH" 2>/dev/null || true
fi

# 2. Khôi phục/Cập nhật Bin/Sbin (Bao gồm lõi maestro_dsp)
if [ -d "${BASE_DIR}/bin" ]; then
    echo "  -> Cập nhật Binary và Script..."
    [ -f "${BASE_DIR}/bin/maestro_dsp" ] && cp -f "${BASE_DIR}/bin/maestro_dsp" /usr/local/bin/maestro_dsp && chmod 755 /usr/local/bin/maestro_dsp
    [ -f "${BASE_DIR}/bin/432squeeze" ] && cp -f "${BASE_DIR}/bin/432squeeze" /usr/local/sbin/432squeeze && chmod 755 /usr/local/sbin/432squeeze
    cp -f "${BASE_DIR}/bin/maestro_apply_"* /usr/local/bin/ 2>/dev/null || true
    chmod 755 /usr/local/bin/maestro_apply_*.sh 2>/dev/null || true
fi

# 3. Khôi phục/Cập nhật Systemd Service
if [ -d "${BASE_DIR}/systemd" ]; then
    echo "  -> Cập nhật dịch vụ Systemd..."
    cp -f "${BASE_DIR}/systemd/"* /etc/systemd/system/ 2>/dev/null || true
fi

# 4. Khôi phục/Cập nhật Cấu hình
if [ -d "${BASE_DIR}/configs" ]; then
    echo "  -> Cập nhật cấu hình..."
    cp -f "${BASE_DIR}/configs/"* /etc/ 2>/dev/null || true
    chmod 666 /etc/maestro_* 2>/dev/null || true
fi

# 5. Khôi phục/Cập nhật Sudoers & Modprobe
if [ -d "${BASE_DIR}/sudoers" ]; then
    cp -f "${BASE_DIR}/sudoers/"* /etc/sudoers.d/ 2>/dev/null || true
    chmod 440 /etc/sudoers.d/maestro_net 2>/dev/null || true
fi
if [ -d "${BASE_DIR}/modprobe" ]; then
    cp -f "${BASE_DIR}/modprobe/"* /etc/modprobe.d/ 2>/dev/null || true
fi

# 6. Ghi nhận phiên bản v2.4.1 vào hệ thống
echo "2.4.1" > /etc/maestro_version 2>/dev/null || true

# 7. Khởi động lại dịch vụ
echo "  -> Tái nạp dịch vụ và khởi động lại trình phát nhạc..."
systemctl daemon-reload 2>/dev/null || true
pkill -9 -f squeezelite 2>/dev/null || true
pkill -9 -f sox 2>/dev/null || true
systemctl restart maestro-player 2>/dev/null || true

echo "[✓] ĐÃ NÂNG CẤP THÀNH CÔNG LÊN PHIÊN BẢN v2.4.1!"
exit 0
