#!/bin/bash
set -e

echo "[+] Bắt đầu nạp các thành phần cập nhật v2.4.1..."

# Cập nhật Lõi Binary C
if [ -f "maestro_dsp" ]; then
    cp -f maestro_dsp /usr/local/bin/maestro_dsp
    chmod 755 /usr/local/bin/maestro_dsp
    chown root:root /usr/local/bin/maestro_dsp
fi

# Cập nhật Lõi Bash điều phối ALSA/DAC
if [ -f "432squeeze" ]; then
    cp -f 432squeeze /usr/local/sbin/432squeeze
    chmod 755 /usr/local/sbin/432squeeze
    chown root:root /usr/local/sbin/432squeeze
fi

# Cập nhật file ghi nhận phiên bản hệ thống
echo "2.4.1" > /etc/maestro_version 2>/dev/null || true

# Khởi động lại dịch vụ âm thanh
pkill -9 -f squeezelite 2>/dev/null || true
pkill -9 -f sox 2>/dev/null || true
systemctl restart maestro-player 2>/dev/null || true

echo "[+] Triển khai bản cập nhật v2.4.1 thành công!"
exit 0
