#!/usr/bin/env bash
set -e
echo "[+] Đang triển khai bản vá Maestro OS v2.4.1..."

BASE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$BASE_DIR"

# Ghi đè file hệ thống
cp -f files/bin/maestro_apply_audio.sh /usr/local/bin/
cp -f files/bin/maestro-update /usr/local/bin/
cp -f files/web/hw.php /var/www/html/
cp -f files/tpl/hw.tpl /var/www/html/templates/

# Phân quyền chuẩn
chmod +x /usr/local/bin/maestro_apply_audio.sh
chmod +x /usr/local/bin/maestro-update
chmod 644 /var/www/html/hw.php
chmod 644 /var/www/html/templates/hw.tpl

# Cập nhật số phiên bản hệ thống lên 2.4.1
for vfile in /etc/maestro_version /var/www/html/version.txt; do
    [ -f "$vfile" ] && echo "2.4.1" > "$vfile"
done

# Khởi tạo file lưu buffer nếu chưa có
if [ ! -f /etc/maestro_buffer_mode ]; then
    echo "balanced" > /etc/maestro_buffer_mode
fi
chmod 666 /etc/maestro_buffer_mode

# Xóa sạch cache template của Smarty
rm -rf /var/www/html/templates_c/*

# Nạp lại cấu hình dịch vụ
systemctl daemon-reload

echo "[+] Nâng cấp thành công lên Maestro OS v2.4.1!"
exit 0
