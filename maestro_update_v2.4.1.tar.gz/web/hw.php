<?php
// Copyright (C) 2022-2026 by AD Audio

require_once('libs/setup.php');
if (file_exists('libs/availableLanguages.php')) { require_once('libs/availableLanguages.php'); }
if (file_exists('libs/tzlist.php')) { require_once('libs/tzlist.php'); }

$config_file = '/var/www/html/config/playergui.cfg';

// 1. Quét thiết bị ALSA
$audio_devices = array('None' => 'None');
if (file_exists('/proc/asound/cards')) {
    $cards = file('/proc/asound/cards');
    foreach ($cards as $line) {
        if (preg_match('/^\s*([0-9]+)\s+\[([^\]]+)\]:\s+(.+)$/', $line, $m)) {
            $card_id = trim($m[2]);
            $audio_devices["hw:CARD=$card_id,DEV=0"] = "hw:CARD=$card_id,DEV=0";
            $audio_devices["plughw:CARD=$card_id,DEV=0"] = "plughw:CARD=$card_id,DEV=0";
        }
    }
}
$audio_devices['default'] = 'default';

// 2. Mảng tùy chọn DSD
$dsd_options = array(
    'dop'       => 'DSD over PCM (DoP)',
    'native_le' => 'Native DSD',
    'none'      => 'Disable DSD (PCM only)'
);

// 3. Mảng tùy chọn Max Sample Rate (Bổ sung 44.1 kHz)
$rate_options = array(
    'none'   => 'Native (Bit-Perfect / No Limit)',
    '44100'  => '44.1 kHz',
    '48000'  => '48 kHz',
    '88200'  => '88.2 kHz',
    '96000'  => '96 kHz',
    '176400' => '176.4 kHz',
    '192000' => '192 kHz',
    '384000' => '384 kHz'
);

$CardList = "";
if (file_exists('/proc/asound/cards')) {
    $CardList = "--- ALSA Soundcards Detected ---\n" . file_get_contents('/proc/asound/cards');
}
if (file_exists('/proc/asound/pcm')) {
    $CardList .= "\n--- ALSA PCM Endpoints ---\n" . file_get_contents('/proc/asound/pcm');
}

$action = isset($_REQUEST['action']) ? $_REQUEST['action'] : '';

if ($action == 'submit' || $action == 'Save Settings' || $_SERVER['REQUEST_METHOD'] === 'POST') {

    // --- MAESTRO SYNC 3 PARAMS ---
    
    
    if (isset($_POST['rate0'])) {
        file_put_contents('/etc/maestro_max_rate', trim($_POST['rate0']) . "\n");
        @chmod('/etc/maestro_max_rate', 0666);
    }

    if (isset($_POST['dsd0'])) {
        file_put_contents('/etc/maestro_dsd_mode', trim($_POST['dsd0']) . "\n");
        @chmod('/etc/maestro_dsd_mode', 0666);
    }

    if (isset($_POST['tuning0'])) {
        file_put_contents('/etc/maestro_pitch_mode', trim($_POST['tuning0']) . "
");
        @chmod('/etc/maestro_pitch_mode', 0666);
    }
    if (isset($_POST['buffer_preset'])) {
        file_put_contents('/etc/maestro_buffer_mode', trim($_POST['buffer_preset']) . "
");
        @chmod('/etc/maestro_buffer_mode', 0666);
    }
    if (isset($_POST['sox_filter'])) {
        file_put_contents('/etc/maestro_sox_filter', trim($_POST['sox_filter']) . "
");
        @chmod('/etc/maestro_sox_filter', 0666);
    }
    // -----------------------------


    // Lưu cấu hình DSP Resampling Filter
    if (isset($_POST['sox_filter']) && !empty($_POST['sox_filter'])) {
        $filter_val = trim($_POST['sox_filter']);
        file_put_contents('/etc/maestro_sox_filter', $filter_val . "
");
        @chmod('/etc/maestro_sox_filter', 0666);
    }


// --- XỬ LÝ LƯU BUFFER TỰ ĐỘNG ---
if (isset($_POST['buffer_preset']) && !empty($_POST['buffer_preset'])) {
    $buffer_preset = trim($_POST['buffer_preset']);
    file_put_contents('/etc/maestro_buffer_mode', $buffer_preset . "
");
    @chmod('/etc/maestro_buffer_mode', 0666);
} else {
    $buffer_preset = file_exists('/etc/maestro_buffer_mode') ? trim(file_get_contents('/etc/maestro_buffer_mode')) : 'deep';
}

    $players = array();
    
        // Tự động nhận diện giá trị Tuning Frequency gửi lên
        $tuning = "440";
        foreach ($_POST as $k => $v) {
            if (preg_match("/(tune|tuning|pitch|freq)/i", $k)) {
                $tuning = trim($v);
                break;
            }
        }
        @file_put_contents("/etc/maestro_pitch_mode", $tuning);

    $buffer_preset = "balanced";
    foreach ($_POST as $k => $v) {
        if (preg_match('/(buffer|alsa_buf)/i', $k) && !empty($v)) {
            $buffer_preset = trim($v);
            break;
        }
    }
    @file_put_contents("/etc/maestro_buffer_mode", $buffer_preset);

@file_put_contents("/etc/maestro_buffer_mode", $buffer_preset);

        for ($i = 0; $i < 3; $i++) {
            // Kept hardware DAC output

        $players[$i]['NAME'] = $_POST["NAME$i"] ?? '';
        $players[$i]['MAC'] = $_POST["MAC$i"] ?? '';
        $players[$i]['DEVICENAME'] = $_POST["DEVICENAME$i"] ?? 'None';
        $players[$i]['DSDMODE'] = $_POST["DSDMODE$i"] ?? 'dop';
        $players[$i]['MAXRATE'] = $_POST["MAXRATE$i"] ?? 'none';
    }
    file_put_contents($config_file, serialize($players));
    chmod($config_file, 0777);

    $dev0 = escapeshellarg($players[0]['DEVICENAME']);
    $dsd0 = escapeshellarg($players[0]['DSDMODE']);
    $name0 = escapeshellarg(!empty($players[0]['NAME']) ? $players[0]['NAME'] : 'USB_DAC');
    $mac0 = escapeshellarg(!empty($players[0]['MAC']) ? $players[0]['MAC'] : '00:04:20:ab:cd:ef');
    $rate0 = escapeshellarg($players[0]['MAXRATE']);
    
        $tuning0 = "440";
        foreach ($_POST as $k => $v) {
            if (preg_match("/(tune|tuning|pitch|freq)/i", $k)) { $tuning0 = trim($v); break; }
        }
        $tuning_arg = escapeshellarg($tuning0);
        
    // Lấy chính xác giá trị buffer_preset gửi từ Web form
    $buffer_preset = '';
    if (isset($_POST['buffer_preset']) && !empty($_POST['buffer_preset'])) {
        $buffer_preset = trim($_POST['buffer_preset']);
    } else {
        foreach ($_POST as $k => $v) {
            if (preg_match("/buffer/i", $k)) { $buffer_preset = trim($v); break; }
        }
    }
    if (empty($buffer_preset)) {
        $buffer_preset = file_exists('/etc/maestro_buffer_mode') ? trim(file_get_contents('/etc/maestro_buffer_mode')) : 'deep';
    }
    file_put_contents('/etc/maestro_buffer_mode', $buffer_preset . "
");
    @chmod('/etc/maestro_buffer_mode', 0666);

    $buffer_arg = escapeshellarg($buffer_preset);
        exec("sudo /usr/local/bin/maestro_apply_audio.sh $dev0 $dsd0 $name0 $mac0 $rate0 $tuning_arg $buffer_arg > /dev/null 2>&1 &");

}

$players = array();
if (file_exists($config_file)) {
    $players = @unserialize(@file_get_contents($config_file));
}

    // Tự động gán DAC nếu cấu hình hiện tại đang là None nhưng có DAC ngoài đang cắm
    if (($players[0]['DEVICENAME'] ?? 'None') === 'None') {
        foreach ($audio_devices as $dev_key => $dev_val) {
            if (strpos($dev_key, 'hw:CARD=') === 0) {
                $players[0]['DEVICENAME'] = $dev_key;
                @file_put_contents($config_file, serialize($players));
                break;
            }
        }
    }



        

        for ($i = 0; $i < 3; $i++) {
            // Kept hardware DAC output

    $smarty->assign("NAME$i", $players[$i]['NAME'] ?? ($i === 0 ? 'USB_DAC' : ''));
    $smarty->assign("MAC$i", $players[$i]['MAC'] ?? ($i === 0 ? '00:04:20:ab:cd:ef' : ''));
    $smarty->assign("DEVICENAME$i", $players[$i]['DEVICENAME'] ?? 'None');
    $smarty->assign("DSDMODE$i", $players[$i]['DSDMODE'] ?? 'dop');
    $smarty->assign("MAXRATE$i", $players[$i]['MAXRATE'] ?? 'none');
}

$smarty->assign('audio_devices', $audio_devices);
$smarty->assign('dsd_options', $dsd_options);
$smarty->assign('rate_options', $rate_options);
$smarty->assign('CardList', $CardList);
$smarty->assign('title', 'Hardware Configuration');

$current_buffer = file_exists("/etc/maestro_buffer_mode") ? trim(file_get_contents("/etc/maestro_buffer_mode")) : "balanced";
$smarty->assign('current_buffer', $current_buffer);

$current_tuning = file_exists("/etc/maestro_pitch_mode") ? trim(file_get_contents("/etc/maestro_pitch_mode")) : "440";
$smarty->assign("current_tuning", $current_tuning);
$current_buffer = file_exists("/etc/maestro_buffer_mode") ? trim(file_get_contents("/etc/maestro_buffer_mode")) : "balanced";
$smarty->assign("current_buffer", $current_buffer);

$current_filter = file_exists('/etc/maestro_sox_filter') ? trim(file_get_contents('/etc/maestro_sox_filter')) : 'minimum';
$smarty->assign('current_filter', $current_filter);


    // NẠP DỮ LIỆU PHẦN CỨNG ALSA TỪ KERNEL LINUX
    $alsa_cards = @file_get_contents('/proc/asound/cards');
    $alsa_pcm = @file_get_contents('/proc/asound/pcm');
    $live_diag = "--- ALSA Soundcards Detected ---\n" . trim($alsa_cards) . "\n\n--- ALSA PCM Endpoints ---\n" . trim($alsa_pcm);
    $smarty->assign('alsa_diag', $live_diag);
    $smarty->assign('diagnostics', $live_diag);
    $smarty->assign('alsa_diagnostics', $live_diag);
    $smarty->assign('alsa_info', $live_diag);
    $smarty->assign('cards', $live_diag);


    // QUET DONG SOUNDCARD TU KERNEL LINUX
    $cards_raw = @file('/proc/asound/cards');
    $audio_dev_list = [];
    if ($cards_raw) {
        foreach ($cards_raw as $cline) {
            $cline = trim($cline);
            if (preg_match('/^(\d+)\s+\[([^\]]+)\]\s*:\s*(.+)$/', $cline, $cm)) {
                $cid = trim($cm[2]);
                $cname = trim($cm[3]);
                $audio_dev_list[] = ['val' => "hw:CARD={$cid},DEV=0", 'label' => "hw:CARD={$cid},DEV=0 ({$cname})"];
                $audio_dev_list[] = ['val' => "plughw:CARD={$cid},DEV=0", 'label' => "plughw:CARD={$cid},DEV=0 ({$cname})"];
            }
        }
    }

    $saved_dev = file_exists('/etc/maestro_audio_device') ? trim(file_get_contents('/etc/maestro_audio_device')) : '';
    $matched = false;
    foreach ($audio_dev_list as &$item) {
        if ($saved_dev !== '' && $item['val'] === $saved_dev) {
            $item['selected'] = true;
            $matched = true;
        } else {
            $item['selected'] = false;
        }
    }
    unset($item);

    // Neu DAC cu da rut hoac chua luu: Tu dong gan card USB dau tien (XMOS)
    if (!$matched && !empty($audio_dev_list)) {
        $audio_dev_list[0]['selected'] = true;
        $saved_dev = $audio_dev_list[0]['val'];
        file_put_contents('/etc/maestro_audio_device', $saved_dev . "\n");
        @chmod('/etc/maestro_audio_device', 0666);
    }

    $cur_dsd = file_exists('/etc/maestro_dsd_mode') ? trim(file_get_contents('/etc/maestro_dsd_mode')) : 'none';
    $smarty->assign('audio_dev_list', $audio_dev_list);
    $smarty->assign('current_dev', $saved_dev);
    $smarty->assign('current_dsd', $cur_dsd);

    $cur_rate = file_exists('/etc/maestro_max_rate') ? trim(file_get_contents('/etc/maestro_max_rate')) : 'none';
    $smarty->assign('current_rate', $cur_rate);


$smarty->display('hw.tpl');
?>

<!-- /* MAESTRO AUTO SWITCH SCRIPT */ -->
<script>
document.addEventListener("DOMContentLoaded", function() {
    // Tìm dropdown Tuning Frequency
    const selects = document.querySelectorAll("select");
    let tuningSelect = null;
    selects.forEach(sel => {
        for (let opt of sel.options) {
            if (opt.text.includes("440 Hz") || opt.value.includes("440")) {
                tuningSelect = sel;
                break;
            }
        }
    });

    const devSelect = document.querySelector('select[name="DEVICENAME0"]') || document.querySelectorAll('table select')[0];
    const rateSelect = document.querySelector('select[name="MAXRATE0"]') || document.querySelectorAll('table select')[2];

    if (!tuningSelect || !devSelect) return;

    function applySmartRouting() {
        const val = tuningSelect.value;
        const text = tuningSelect.options[tuningSelect.selectedIndex].text;

        if (text.includes("440") || val.includes("440") || val.includes("bypass")) {
            // Chế độ 440 Hz: Chuyển về Outputs thật & Native Bit-Perfect
            for (let opt of devSelect.options) {
                if (opt.value.includes("Outputs") || opt.text.includes("Outputs")) {
                    devSelect.value = opt.value;
                    break;
                }
            }
            if (rateSelect) {
                for (let opt of rateSelect.options) {
                    if (opt.value === "none" || opt.text.includes("Native") || opt.text.includes("Bit-Perfect")) {
                        rateSelect.value = opt.value;
                        break;
                    }
                }
            }
        } else {
            // Chế độ Pitch Shift (432, 430.5, 426.6): Tự chuyển sang Loopback
            for (let opt of devSelect.options) {
                if (opt.value.includes("Loopback") || opt.text.includes("Loopback")) {
                    devSelect.value = opt.value;
                    break;
                }
            }
        }
    }

    tuningSelect.addEventListener("change", applySmartRouting);
});
</script>
