<?php
header("Location: plugin.php");
exit;
?>
