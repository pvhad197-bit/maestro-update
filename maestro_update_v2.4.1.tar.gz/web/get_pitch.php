<?php
if (file_exists('/etc/maestro_pitch_mode')) {
    echo trim(file_get_contents('/etc/maestro_pitch_mode'));
} else {
    echo "440";
}
?>
