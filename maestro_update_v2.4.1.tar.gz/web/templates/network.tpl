{include file="header.tpl"}

{if $message}
<div style="margin-bottom: 20px; padding: 12px 16px; border-radius: 6px; font-size: 13px; {if $msg_type == 'success'}background: #dcfce7; color: #15803d; border: 1px solid #bbf7d0;{else}background: #fee2e2; color: #b91c1c; border: 1px solid #fca5a5;{/if}">
    {$message}
</div>
{/if}

<div style="max-width: 760px; margin: 0 auto 30px auto;">
    <div class="section-box" style="background: #fff; border: 1px solid #e2e8f0; border-radius: 8px; padding: 24px; box-shadow: 0 1px 3px rgba(0,0,0,0.05);">
        <!-- Header -->
        <div style="display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid #f1f5f9; padding-bottom: 14px; margin-bottom: 16px;">
            <h3 style="margin: 0; font-size: 16px; font-weight: 700; color: #1e293b;">Ethernet (LAN)</h3>
            {if $lan_info.status == 'Connected'}
                <span style="background: #dcfce7; color: #16a34a; font-size: 12px; font-weight: 600; padding: 3px 12px; border-radius: 12px;">Connected</span>
            {else}
                <span style="background: #fee2e2; color: #ef4444; font-size: 12px; font-weight: 600; padding: 3px 12px; border-radius: 12px;">Disconnected</span>
            {/if}
        </div>

        <!-- Current Info Table -->
        <table style="width: 100%; font-size: 13px; line-height: 2.2;">
            <tr><td style="color: #64748b; width: 40%;">Interface:</td><td style="font-weight: 600; color: #1e293b;">{$lan_info.interface}</td></tr>
            <tr><td style="color: #64748b;">Link Status:</td><td style="font-weight: 600; color: #16a34a;">{$lan_info.link_state}</td></tr>
            <tr><td style="color: #64748b;">Link Speed:</td><td style="font-weight: 600; color: #1e293b;">{$lan_info.speed}</td></tr>
            <tr>
                <td style="color: #64748b;">IP Mode:</td>
                <td style="font-weight: 600; color: #1e293b;">
                    {if $lan_info.mode == 'static'}
                        <span style="background: #e0f2fe; color: #0369a1; padding: 2px 8px; border-radius: 4px; font-size: 12px;">Static IP</span>
                    {else}
                        <span style="background: #f1f5f9; color: #475569; padding: 2px 8px; border-radius: 4px; font-size: 12px;">Dynamic (DHCP)</span>
                    {/if}
                </td>
            </tr>
            <tr><td style="color: #64748b;">IP Address:</td><td style="font-weight: 600; color: #1e293b;">{$lan_info.ip}</td></tr>
            <tr><td style="color: #64748b;">Subnet Mask:</td><td style="font-weight: 600; color: #1e293b;">{$lan_info.netmask}</td></tr>
            <tr><td style="color: #64748b;">Default Gateway:</td><td style="font-weight: 600; color: #1e293b;">{$lan_info.gateway}</td></tr>
            <tr><td style="color: #64748b;">DNS Server:</td><td style="font-weight: 600; color: #1e293b;">{$lan_info.dns}</td></tr>
            <tr><td style="color: #64748b;">MAC Address:</td><td style="font-weight: 600; color: #1e293b;">{$lan_info.mac}</td></tr>
        </table>

        <!-- IP Settings Box -->
        <div style="margin-top: 24px; border-top: 1px solid #f1f5f9; padding-top: 20px;">
            <h4 style="margin: 0 0 16px 0; font-size: 15px; font-weight: 700; color: #1e293b;">IP Configuration</h4>
            
            <form action="/network.php?action=set_ip" method="post" id="ipForm">
                <div style="display: flex; gap: 24px; margin-bottom: 18px; flex-wrap: wrap;">
                    <label style="display: flex; align-items: center; gap: 8px; font-size: 13px; font-weight: 600; color: #334155; cursor: pointer;">
                        <input type="radio" name="ip_mode" value="dhcp" {if $lan_info.mode != 'static'}checked{/if} onchange="toggleStaticFields(false)">
                        Dynamic IP (DHCP - Automatic)
                    </label>
                    <label style="display: flex; align-items: center; gap: 8px; font-size: 13px; font-weight: 600; color: #334155; cursor: pointer;">
                        <input type="radio" name="ip_mode" value="static" {if $lan_info.mode == 'static'}checked{/if} onchange="toggleStaticFields(true)">
                        Static IP (Manual)
                    </label>
                </div>

                <!-- Static IP Fields -->
                <div id="static_fields_container" style="{if $lan_info.mode != 'static'}display: none;{/if} background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 6px; padding: 18px; margin-bottom: 20px;">
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 14px;">
                        <div>
                            <label style="display: block; font-size: 12px; font-weight: 600; color: #475569; margin-bottom: 6px;">IP Address</label>
                            <input type="text" name="static_ip" value="{$lan_info.ip}" placeholder="192.168.1.50" style="width: 100%; height: 36px; padding: 0 12px; border: 1px solid #cbd5e1; border-radius: 5px; font-size: 13px; box-sizing: border-box;">
                        </div>
                        <div>
                            <label style="display: block; font-size: 12px; font-weight: 600; color: #475569; margin-bottom: 6px;">Subnet Mask</label>
                            <input type="text" name="netmask" value="{$lan_info.netmask}" placeholder="255.255.255.0" style="width: 100%; height: 36px; padding: 0 12px; border: 1px solid #cbd5e1; border-radius: 5px; font-size: 13px; box-sizing: border-box;">
                        </div>
                        <div>
                            <label style="display: block; font-size: 12px; font-weight: 600; color: #475569; margin-bottom: 6px;">Default Gateway</label>
                            <input type="text" name="gateway" value="{$lan_info.gateway}" placeholder="192.168.1.1" style="width: 100%; height: 36px; padding: 0 12px; border: 1px solid #cbd5e1; border-radius: 5px; font-size: 13px; box-sizing: border-box;">
                        </div>
                        <div>
                            <label style="display: block; font-size: 12px; font-weight: 600; color: #475569; margin-bottom: 6px;">DNS Server</label>
                            <input type="text" name="dns" value="{$lan_info.dns}" placeholder="8.8.8.8, 1.1.1.1" style="width: 100%; height: 36px; padding: 0 12px; border: 1px solid #cbd5e1; border-radius: 5px; font-size: 13px; box-sizing: border-box;">
                        </div>
                    </div>
                    <div style="font-size: 12px; color: #64748b; margin-top: 12px;">
                        * Note: If you change the static IP address, please enter the new address in your browser URL bar to reconnect.
                    </div>
                </div>

                <button type="submit" style="height: 38px; padding: 0 22px; font-size: 13px; font-weight: 600; background: #0284c7; color: #fff; border: none; border-radius: 5px; cursor: pointer;">
                    Save Network Settings
                </button>
            </form>
        </div>
    </div>
</div>

<script>
function toggleStaticFields(show) {
    var el = document.getElementById('static_fields_container');
    if (el) {
        el.style.display = show ? 'block' : 'none';
    }
}
</script>

{include file="footer.tpl"}
