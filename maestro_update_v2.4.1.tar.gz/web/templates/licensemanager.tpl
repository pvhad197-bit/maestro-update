{include file="header.tpl"}

<script type="text/javascript" src="/js/ajax.js"> </script>

<div class="xsnazzy">
<b class="xtop"><b class="xb1"></b><b class="xb2 color_c">
</b><b class="xb3 color_c"></b><b class="xb4 color_c"></b></b>
 <div class="xboxcontent">
 <h1 class="color_c">{t}License Manager{/t} {include file='tooltip.tpl' Name='VortexBox License Manager' File='licensemanager'}</h1>
  <div>
   <form action="/hw.php?action=submit" method="post">
	<p><b>{t}MakeMKV License{/t}:</b>   ({t}Buy a license <a href="http://makemkv.com/buy/" target="_blank" >here</a> if you don't have one.{/t})</p>
	<p><input type="text" name="MAKEMKVLICENSE" value="{$MAKEMKVLICENSE}" size="90"></p>
    <br>
    <p><input type="submit" value="{t}Submit{/t}"></p>
   </form>
  </div>
 <br>
 <p></p>
 </div>
<b class="xbottom"><b class="xb4"></b><b class="xb3"></b>
<b class="xb2"></b><b class="xb1"></b></b>
</div>

{include file="footer.tpl"}
