{include file="header.tpl"}

<div class="xsnazzy" style="-webkit-text-size-adjust: 100%; text-size-adjust: 100%; font-size: 15px;">
<b class="xtop"><b class="xb1"></b><b class="xb2 color_a">
</b><b class="xb3 color_a"></b><b class="xb4 color_a"></b></b>
<p>{t}Welcome to your Maestro Music Server by AD Audio{/t}</p>
<div style="display: flex; align-items: center; gap: 8px; margin: 8px 0;">
    <b>{t}System name{/t}:</b>
    <span id="sysname-label" style="font-weight: bold; color: #0d6efd; font-size: 15px;">{$SYSNAME}</span>
    <button type="button" onclick="document.getElementById('sysname-form').style.display='inline-flex'; document.getElementById('sysname-label').style.display='none'; this.style.display='none';" style="border: 1px solid #ced4da; background: #e9ecef; border-radius: 4px; padding: 1px 8px; font-size: 12px; cursor: pointer;">Edit</button>

    <form id="sysname-form" method="post" action="index.php" style="display: none; align-items: center; gap: 6px; margin: 0;">
        <input type="hidden" name="action" value="change_sysname">
        <input type="text" name="new_sysname" value="{$SYSNAME}" pattern="[a-zA-Z0-9\-]+" title="Chỉ dùng chữ cái không dấu, số và dấu gạch ngang" style="padding: 2px 8px; font-size: 13px; border: 1px solid #0d6efd; border-radius: 4px; width: 130px;" required>
        <button type="submit" style="background: #198754; color: #fff; border: none; padding: 2px 10px; border-radius: 4px; font-size: 12px; cursor: pointer;">Save</button>
        <button type="button" onclick="location.reload();" style="background: #6c757d; color: #fff; border: none; padding: 2px 8px; border-radius: 4px; font-size: 12px; cursor: pointer;">Cancel</button>
    </form>
</div>
{if isset($smarty.get.updated_sysname)}
    <div style="background: #d1e7dd; color: #0f5132; padding: 6px 12px; border-radius: 4px; margin-bottom: 12px; font-size: 13px; border-left: 4px solid #198754;">
        Đã đổi tên hệ thống thành <strong>{$smarty.get.updated_sysname}</strong>. Tên miền truy cập mới: <strong>http://{$smarty.get.updated_sysname}.local</strong>
    </div>
{/if}
<p><b>{t}OS Version{/t}:</b> Maestro OS v{$os_version} <button type="submit" form="ota_update_form" class="btn btn-default btn-xs" style="margin-left: 6px; vertical-align: middle;" onclick="return confirm('Do you want to check and install the latest system update?');">Update</button></p>
<form id="ota_update_form" method="post" action="index.php" style="display:none;">
    <input type="hidden" name="action_do_update" value="1">
</form>
{if isset($ota_log) && $ota_log != ''}
<div style="margin-top: 6px; margin-bottom: 6px;">
    <pre style="background: #181818; color: #00ff66; padding: 10px; border-radius: 4px; font-size: 12px; max-width: 650px; white-space: pre-wrap; margin: 0;"><code>{$ota_log}</code></pre>
</div>
{/if}
<p><b>{if isset($NIC) && $NIC|substr:0:2 == 'wl'}wlan0{else}eth0{/if} IP:</b> {$IPADDRESS}</p>
<p><b>Machine ID:</b> <span style="color:#d63384; font-weight:bold;">{$MACADDRESS}</span></p>

<div class="drive">
 <table>
<tr><th>{t}Storage{/t}</th>
<th>{t}Size{/t}</th>
<th>{t}Used{/t}</th>
<th>{t}Available{/t}</th>
<th>{t}Use%{/t}</th>
</tr>
{foreach from=$DRIVES item=drive}
<tr><td>{$drive.name}</td>
<td>{$drive.size}</td>
<td>{$drive.used}</td>
<td>{$drive.avail}</td>
<td>{$drive.percent}</td>
</tr>
{/foreach}
 </table>
<p></p>
</div>

<!-- LICENSE & ACTIVATION -->
<div style="margin-top: 20px; border-top: 1px dashed #ccc; padding-top: 15px;">
    <p><b>License Status:</b></p>
    <pre style="background: #eef2f5; padding: 10px; border-radius: 5px; font-family: monospace; font-size: 13px; border-left: 4px solid #007bff; white-space: pre-wrap;">{$LICENSE_STATUS}</pre>
    
    {$LICENSE_MSG}

<div style="margin-top: 15px;">
    <form method="POST" action="index.php" style="display: flex; gap: 10px; justify-content: center; align-items: center; max-width: 800px; margin: 0 auto;">
        <input type="text" name="license_key" placeholder="ENTER LICENSE KEY (E.G. YEAR-20260823-A1B2C3...)" style="flex: 1; padding: 10px; border: 1px solid #ccc; border-radius: 4px; font-family: monospace; font-size: 13px; text-transform: uppercase;" required>
        <button type="submit" style="background-color: #28a745; color: white; border: none; padding: 10px 24px; font-weight: bold; border-radius: 4px; cursor: pointer;">Activate</button>
    </form>
</div>

</div>

<b class="xbottom"><b class="xb4"></b><b class="xb3"></b>
<b class="xb2"></b><b class="xb1"></b></b>
</div>

{include file="footer.tpl"}
