{include file="header.tpl"}

<div class="xsnazzy">
<b class="xtop"><b class="xb1"></b><b class="xb2 color_b"></b><b class="xb3 color_b"></b><b class="xb4 color_b"></b></b>
<div class="xboxcontent">
<h1 class="color_b">{t}NAS Network Storage{/t}</h1>

{if $status_msg == 'success'}
    <p style="color:green; font-weight:bold;">{t}Success: The system is connecting to network storage in the background (please wait 3-5s)...{/t}</p>
{/if}
{if $status_msg == 'disconnected'}
    <p style="color:blue; font-weight:bold;">{t}NAS Network Storage has been disconnected successfully.{/t}</p>
{/if}
{if $status_msg == 'ip_error'}
    <p style="color:red; font-weight:bold;">{t}Error: NAS IP address not found in the network! Please check your device connection.{/t}</p>
{/if}
{if $status_msg == 'error'}
    <p style="color:red; font-weight:bold;">{t}Error: Please enter both the IP Address and Shared Folder Name!{/t}</p>
{/if}

<p><b>Storage Status:</b> 
{if $is_mounted}
    <span style="color: green; font-weight: bold;">Mounted & Ready (/storage/nas_music)</span>
{else}
    <span style="color: red; font-weight: bold;">Not Connected</span>
{/if}
</p>
<hr>

<form action="nas.php?action=submit" method="post">
<div style="max-width: 600px; margin: 0 auto;">
<div class="texttable">
  <table style="width: 100%;">
<tr class="odd">
<td style="font-weight: bold; width: 220px;">{t}NAS IP Address{/t}:</td>
<td><input type="text" name="nas_ip" value="{$nas_ip}" style="width: 100%; padding: 6px; box-sizing: border-box;" placeholder="e.g. 192.168.1.5"></td>
</tr>
<tr>
<td style="font-weight: bold;">{t}Shared Folder Name{/t}:</td>
<td><input type="text" name="nas_folder" value="{$nas_folder}" style="width: 100%; padding: 6px; box-sizing: border-box;" placeholder="e.g. music"></td>
</tr>
<tr class="odd">
<td style="font-weight: bold;">{t}Username (Leave blank if guest){/t}:</td>
<td><input type="text" name="nas_user" value="{$nas_user}" style="width: 100%; padding: 6px; box-sizing: border-box;"></td>
</tr>
<tr>
<td style="font-weight: bold;">{t}Password{/t}:</td>
<td><input type="password" name="nas_pass" value="{$nas_pass}" style="width: 100%; padding: 6px; box-sizing: border-box;"></td>
</tr>
  </table>
</div>

<div style="text-align: center; margin-top: 20px;">
<input type="submit" value="{t}Connect NAS Storage{/t}" style="padding: 8px 20px; font-weight: bold; cursor: pointer; border-radius: 3px;" />
{if $is_mounted}
<a href="nas.php?action=disconnect" style="padding: 8px 20px; margin-left: 15px; background-color: #d9534f; color: white; text-decoration: none; font-weight: bold; border-radius: 3px; display: inline-block;">Disconnect</a>
{/if}
</div>
</div>
</form>
<br>
</div>
<b class="xbottom"><b class="xb4"></b><b class="xb3"></b><b class="xb2"></b><b class="xb1"></b></b>
</div>

{include file="footer.tpl"}
