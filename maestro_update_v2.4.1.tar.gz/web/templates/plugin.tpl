{include file="header.tpl"}

<div class="container" style="max-width: 820px; margin: 25px auto; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; -webkit-text-size-adjust: 100%;">
    <div style="background: #ffffff; border: 1px solid #e2e8f0; border-radius: 10px; padding: 25px; box-shadow: 0 4px 12px rgba(0,0,0,0.03);">
        <h3 style="margin-top: 0; color: #0d6efd; font-weight: 700;">Remote Access & Network Hub</h3>
        <p style="color: #64748b; font-size: 14px; margin-bottom: 25px;">
            Centralized virtual networking hub for Maestro OS. Connect your server to a remote NAS or PC music library securely over the internet.
        </p>

        <!-- 1. TAILSCALE VPN -->
        <div style="border: 1px solid #e2e8f0; border-radius: 8px; padding: 18px; margin-bottom: 20px; background: #fafafa;">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px;">
                <h4 style="margin: 0; color: #1e293b; font-size: 16px;">1. Tailscale VPN</h4>
                {if $ts_active}
                    <span style="color: #16a34a; font-weight: 700; font-size: 13px;">● Connected ({$ts_ip})</span>
                {else}
                    <span style="color: #64748b; font-weight: 600; font-size: 13px;">○ Disconnected</span>
                {/if}
            </div>
            <p style="font-size: 13px; color: #64748b; margin-bottom: 12px;">One-click browser authorization to seamlessly access your home music vault from anywhere.</p>

            {if $ts_active}
                <form method="post" style="display: inline;">
                    <input type="hidden" name="action" value="ts_disconnect">
                    <button type="submit" style="background: #dc2626; color: #fff; border: none; padding: 6px 14px; border-radius: 4px; font-size: 13px; cursor: pointer;">Disconnect</button>
                </form>
                <a href="nas.php" style="margin-left: 10px; font-size: 13px; color: #0d6efd; text-decoration: none; font-weight: 600;">Configure NAS Storage &rarr;</a>
            {else}
                {if !empty($ts_login_url)}
                    <div style="background: #fefce8; border: 1px solid #fef08a; padding: 12px; border-radius: 6px; margin-bottom: 10px;">
                        <a href="{$ts_login_url}" target="_blank" style="display: inline-block; background: #0d6efd; color: #fff; text-decoration: none; padding: 7px 16px; border-radius: 4px; font-weight: 700; font-size: 13px;">👉 Click Here to Authenticate Device</a>
                    </div>
                    <button type="button" onclick="location.reload();" style="background: #16a34a; color: #fff; border: none; padding: 6px 14px; border-radius: 4px; font-size: 13px; cursor: pointer;">Check Connection</button>
                {else}
                    <form method="post">
                        <input type="hidden" name="action" value="ts_generate">
                        <button type="submit" style="background: #0d6efd; color: #fff; border: none; padding: 7px 16px; border-radius: 4px; font-weight: 600; font-size: 13px; cursor: pointer;">Generate Tailscale Login Link</button>
                    </form>
                {/if}
            {/if}
        </div>

        <!-- 2. ZEROTIER NETWORK -->
        <div style="border: 1px solid #e2e8f0; border-radius: 8px; padding: 18px; background: #fafafa;">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px;">
                <h4 style="margin: 0; color: #1e293b; font-size: 16px;">2. WireGuard (.conf)</h4>
                {if $wg_active}
                    <span style="color: #16a34a; font-weight: 700; font-size: 13px;">● Interface wg0 Active</span>
                {else}
                    <span style="color: #64748b; font-weight: 600; font-size: 13px;">○ Inactive</span>
                {/if}
            </div>
            <p style="font-size: 13px; color: #64748b; margin-bottom: 12px;">Upload a <code>.conf</code> client configuration profile exported from your router or server.</p>

            {if $wg_active}
                <form method="post" style="display: inline;">
                    <input type="hidden" name="action" value="wg_down">
                    <button type="submit" style="background: #dc2626; color: #fff; border: none; padding: 6px 14px; border-radius: 4px; font-size: 13px; cursor: pointer;">Disable WireGuard</button>
                </form>
            {else}
                <form method="post" enctype="multipart/form-data" style="display: flex; gap: 8px; align-items: center;">
                    <input type="hidden" name="action" value="wg_upload">
                    <input type="file" name="wg_conf" accept=".conf" style="font-size: 13px;" required>
                    <button type="submit" style="background: #198754; color: #fff; border: none; padding: 7px 16px; border-radius: 4px; font-weight: 600; font-size: 13px; cursor: pointer;">Upload & Connect</button>
                </form>
            {/if}
        </div>

        <hr style="border: 0; border-top: 1px solid #f1f5f9; margin: 30px 0 20px 0;">
        
       </div>

{include file="footer.tpl"}
