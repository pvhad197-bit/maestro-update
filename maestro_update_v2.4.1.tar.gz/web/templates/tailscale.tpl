{include file="header.tpl"}

<div class="container" style="max-width: 760px; margin: 30px auto; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;">
    <div style="background: #ffffff; border: 1px solid #e2e8f0; border-radius: 10px; padding: 30px; box-shadow: 0 4px 12px rgba(0,0,0,0.03);">
        <h3 style="margin-top: 0; color: #0d6efd; font-weight: 700;">Tailscale Remote VPN</h3>
        <p style="color: #64748b; font-size: 14px; margin-bottom: 20px;">
            Kết nối máy chủ Maestro vào mạng riêng ảo Tailscale để phát nhạc từ xa từ ổ NAS hoặc máy tính đặt ở mạng khác qua Internet.
        </p>
        <hr style="border: 0; border-top: 1px solid #f1f5f9; margin-bottom: 24px;">

        <div style="margin-bottom: 24px;">
            <label style="font-weight: 600; color: #334155;">Trạng thái kết nối:</label>
            {if $is_connected}
                <span style="color: #16a34a; font-weight: 700; margin-left: 6px;">● Đang hoạt động (Online)</span>
                <div style="margin-top: 12px; background: #f0fdf4; border: 1px solid #bbf7d0; padding: 14px; border-radius: 8px;">
                    <span style="color: #166534; font-size: 14px;">Địa chỉ IP Tailscale của Maestro:</span><br>
                    <strong style="font-size: 20px; color: #0d6efd; letter-spacing: 0.5px;">{$ts_ip}</strong>
                </div>
            {else}
                <span style="color: #dc2626; font-weight: 700; margin-left: 6px;">○ Chưa kết nối (Offline)</span>
            {/if}
        </div>

        {if $is_connected}
            <form method="post" style="display: flex; gap: 10px; align-items: center; margin-top: 15px;">
                <input type="hidden" name="action" value="disconnect">
                <button type="submit" style="background: #dc2626; color: #fff; border: none; padding: 9px 18px; border-radius: 6px; font-weight: 600; cursor: pointer;">Ngắt kết nối mạng này</button>
                <a href="nas.php" style="background: #0d6efd; color: #fff; text-decoration: none; padding: 9px 18px; border-radius: 6px; font-weight: 600; display: inline-block;">Đi tới cấu hình NAS Storage</a>
            </form>
        {else}
            {if !empty($login_url)}
                <div style="background: #fefce8; border: 1px solid #fef08a; padding: 18px; border-radius: 8px; margin-bottom: 20px;">
                    <p style="margin: 0 0 12px 0; font-weight: 700; color: #854d0e;">Bước 2: Cấp quyền tham gia mạng</p>
                    <a href="{$login_url}" target="_blank" style="display: inline-block; background: #0d6efd; color: #ffffff; text-decoration: none; padding: 11px 22px; border-radius: 6px; font-weight: 700;">👉 Bấm vào đây để Đăng Nhập Tailscale</a>
                    <p style="font-size: 13px; color: #854d0e; margin: 12px 0 0 0;">
                        Sau khi tab mới hiện thông báo thành công, hãy bấm nút <strong>Kiểm tra kết nối</strong> phía dưới.
                    </p>
                </div>
                <button type="button" onclick="location.reload();" style="background: #16a34a; color: #fff; border: none; padding: 10px 20px; border-radius: 6px; font-weight: 600; cursor: pointer;">Đã duyệt xong, kiểm tra kết nối</button>
            {else}
                <form method="post">
                    <input type="hidden" name="action" value="generate_link">
                    <button type="submit" style="background: #0d6efd; color: #ffffff; border: none; padding: 11px 24px; border-radius: 6px; font-weight: 700; font-size: 15px; cursor: pointer;">Tạo liên kết đăng nhập Tailscale</button>
                </form>
            {/if}
        {/if}

        <hr style="border: 0; border-top: 1px solid #f1f5f9; margin: 30px 0 20px 0;">
        <div style="font-size: 13px; color: #64748b; line-height: 1.6;">
            <strong style="color: #334155;">3 bước kết nối ổ NAS từ xa:</strong>
            <ol style="padding-left: 18px; margin-top: 6px; margin-bottom: 0;">
                <li>Bấm tạo link ở trên và đăng nhập cùng tài khoản Tailscale với ổ NAS (hoặc PC chứa nhạc).</li>
                <li>Vào trang quản trị Tailscale copy IP ảo của ổ NAS (dạng <code>100.x.y.z</code>).</li>
                <li>Vào mục <strong>NAS Storage</strong> của Maestro, dán IP <code>100.x.y.z</code> vào ô <em>NAS IP Address</em> và bấm <strong>Submit</strong>.</li>
            </ol>
        </div>
    </div>
</div>

{include file="footer.tpl"}
