
<style>
/* MAESTRO UNIFIED CONTROLS ALIGNMENT */
.maestro-control-group {
    max-width: 780px;
    margin: 25px auto 25px auto;
    display: flex;
    flex-direction: column;
    gap: 16px;
}
.maestro-control-row {
    display: flex;
    align-items: center;
    justify-content: center;
    width: 100%;
}
.maestro-label {
    width: 210px;
    min-width: 210px;
    text-align: right;
    font-weight: 700;
    font-size: 14px;
    color: #2c3e50;
    margin-right: 18px;
    margin-bottom: 0;
    white-space: nowrap;
}
.maestro-select-input {
    width: 520px;
    max-width: 520px;
    height: 42px;
    padding: 6px 14px;
    font-size: 14px;
    font-weight: 500;
    color: #1f2937;
    background-color: #ffffff;
    border: 1px solid #d1d5db;
    border-radius: 8px;
    box-shadow: 0 1px 2px rgba(0, 0, 0, 0.05);
    outline: none;
    transition: all 0.2s ease;
    cursor: pointer;
}
.maestro-select-input:focus {
    border-color: #4f46e5;
    box-shadow: 0 0 0 3px rgba(79, 70, 229, 0.15);
}
@media (max-width: 768px) {
    .maestro-control-group {
        max-width: 100%;
        gap: 14px;
        padding: 0 10px;
    }
    .maestro-control-row {
        flex-direction: column;
        align-items: flex-start;
    }
    .maestro-label {
        width: 100%;
        min-width: 100%;
        text-align: left;
        margin-right: 0;
        margin-bottom: 6px;
    }
    .maestro-select-input {
        width: 100%;
        max-width: 100%;
    }
}
</style>

{include file="header.tpl"}

<style>
/* Maestro Responsive & Compact UI */
.maestro-wrap {
    max-width: 880px;
    margin: 15px auto;
    padding: 0 10px;
}
.maestro-card {
    background: #ffffff;
    border: 1px solid #e2e8f0;
    border-radius: 8px;
    padding: 22px;
    margin-bottom: 22px;
    box-shadow: 0 1px 4px rgba(0,0,0,0.05);
}
.maestro-title {
    text-align: center;
    font-weight: bold;
    font-size: 20px;
    color: #1e293b;
    margin-top: 2px;
    margin-bottom: 18px;
}
.maestro-subtitle {
    font-weight: bold;
    font-size: 16px;
    color: #1e293b;
    margin-top: 4px;
    margin-bottom: 12px;
}
.maestro-table {
    width: 100%;
    border-collapse: collapse;
    margin-bottom: 18px;
}
.maestro-table th {
    background: #f8fafc;
    color: #475569;
    font-weight: 600;
    font-size: 13.5px;
    padding: 9px 6px;
    text-align: center;
    border: 1px solid #cbd5e1;
}
.maestro-table td {
    padding: 6px;
    text-align: center;
    border: 1px solid #cbd5e1;
    vertical-align: middle;
}
.maestro-tbl-ctrl {
    width: 100% !important;
    height: 38px !important;
    font-size: 13.5px !important;
    padding: 4px 8px !important;
    border: 1px solid #cbd5e1 !important;
    border-radius: 4px !important;
    background: #fff !important;
    color: #0f172a !important;
}
.maestro-row {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 12px;
    margin: 11px 0;
}
.maestro-lbl {
    width: 200px;
    text-align: right;
    font-weight: bold;
    font-size: 14px;
    color: #334155;
    margin: 0;
}
.maestro-sel {
    width: 440px;
    max-width: 100%;
    height: 38px !important;
    font-size: 13.5px !important;
    padding: 4px 10px !important;
    border: 1px solid #cbd5e1 !important;
    border-radius: 5px !important;
    background: #fff !important;
    color: #0f172a !important;
}
.maestro-btn {
    padding: 10px 42px;
    font-size: 15px;
    font-weight: bold;
    background-color: #3b82f6;
    color: #fff;
    border: none;
    border-radius: 6px;
    cursor: pointer;
    box-shadow: 0 2px 8px rgba(59, 130, 246, 0.35);
    transition: background 0.15s ease;
}
.maestro-btn:hover {
    background-color: #2563eb;
}
.maestro-diag-box {
    background: #ffffff;
    border: 1px solid #cbd5e1;
    border-radius: 6px;
    padding: 15px;
    font-family: monospace;
    font-size: 13px;
    color: #334155;
    line-height: 1.5;
    white-space: pre-wrap;
    margin-bottom: 20px;
}
.maestro-guide {
    font-size: 13.5px;
    color: #475569;
    line-height: 1.6;
}

/* Tối ưu màn hình Điện thoại */
@media (max-width: 768px) {
    .maestro-card { padding: 14px 10px; margin-bottom: 15px; }
    .maestro-table { display: block; overflow-x: auto; }
    .maestro-row { flex-direction: column; align-items: stretch; gap: 4px; margin: 12px 0; }
    .maestro-lbl { width: 100%; text-align: left; font-size: 13.5px; }
    .maestro-sel { width: 100% !important; height: 46px !important; font-size: 15px !important; }
    .maestro-btn { width: 100%; height: 46px; font-size: 16px; }
}
</style>

<div class="maestro-wrap">
    <!-- CARD 1: HARDWARE CONFIGURATION -->
    <div class="maestro-card">
        <div class="maestro-title">Hardware Configuration</div>
        <form action="hw.php" method="post" id="hwForm">
            <table class="maestro-table">
                <thead>
                    <tr>
                        <th style="width: 22%;">Player Name</th>
                        <th style="width: 30%;">Audio Output Device</th>
                        <th style="width: 24%;">DSD Output Mode</th>
                        <th style="width: 24%;">Max Sample Rate</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td><input type="text" name="name0" value="{$name0|default:'USB_DAC'}" class="maestro-tbl-ctrl" style="text-align: center; font-weight: bold;"></td>
                        <td>
                            <select name="dev0" class="maestro-tbl-ctrl">
                            {if $audio_dev_list}
                                {foreach from=$audio_dev_list item=item}
                                    <option value="{$item.val}" {if $item.selected}selected{/if}>{$item.label}</option>
                                {/foreach}
                            {else}
                                <option value="hw:CARD=audio,DEV=0" selected>hw:CARD=audio,DEV=0 (XMOS usb audio)</option>
                                <option value="plughw:CARD=audio,DEV=0">plughw:CARD=audio,DEV=0 (XMOS usb audio)</option>
                            {/if}
                        </select>
                        </td>
                        <td>
                            <select name="dsd0" class="maestro-tbl-ctrl">
                            <option value="none" {if $current_dsd == 'none' || !$current_dsd}selected{/if}>Disable DSD (PCM only)</option>
                            <option value="dop" {if $current_dsd == 'dop'}selected{/if}>DSD over PCM (DoP)</option>
                            <option value="native" {if $current_dsd == 'native'}selected{/if}>Native DSD</option>
                        </select>
                        </td>
                        <td>
                            <select name="rate0" class="maestro-tbl-ctrl">
                            <option value="none" {if $current_rate == 'none' || !$current_rate}selected{/if}>Native (Bit-Perfect / No Limit)</option>
                            <option value="768" {if $current_rate == '768'}selected{/if}>768 kHz</option>
                            <option value="384" {if $current_rate == '384'}selected{/if}>384 kHz</option>
                            <option value="192" {if $current_rate == '192'}selected{/if}>192 kHz</option>
                            <option value="176.4" {if $current_rate == '176.4'}selected{/if}>176.4 kHz</option>
                            <option value="96" {if $current_rate == '96'}selected{/if}>96 kHz</option>
                            <option value="88.2" {if $current_rate == '88.2'}selected{/if}>88.2 kHz</option>
                            <option value="48" {if $current_rate == '48'}selected{/if}>48 kHz</option>
                            <option value="44.1" {if $current_rate == '44.1'}selected{/if}>44.1 kHz</option>
                        </select>
                        </td>
                    </tr>
                </tbody>
            </table>

            <!-- 1. TUNING FREQUENCY -->
            <div class="maestro-row" style="margin-top: 18px;">
                <div class="maestro-control-group">
        <div class="maestro-control-row">
            <label class="maestro-label">Tuning Frequency:</label>
            <select name="tuning0" class="maestro-select-input">
                <option value="direct" {if $current_tuning == 'direct' || $current_tuning == 'none' || $current_tuning == 'analog_warm' || $current_tuning == 'analog_deep' || !$current_tuning}selected{/if}>Direct Bit-Perfect (Pure Sound / 440 Hz)</option>
                <option value="435" {if $current_tuning == '435'}selected{/if}>435 Hz - Diapason Normal (Vocal / Warm)</option>
                <option value="432" {if $current_tuning == '432'}selected{/if}>432 Hz - Natural (Verdi)</option>
                <option value="430.5" {if $current_tuning == '430.5'}selected{/if}>430.5 Hz - Scientific (C=256 Hz)</option>
                <option value="426.6" {if $current_tuning == '426.6'}selected{/if}>426.6 Hz - Pure Harmonic</option>
            </select>
        </div>

        <div class="maestro-control-row">
            <label class="maestro-label">ALSA Buffer Preset:</label>
            <select name="buffer_preset" class="maestro-select-input">
                <option value="tight" {if $current_buffer == 'tight'}selected{/if}>Tight (10ms buffer, ultra-fast transient)</option>
                <option value="balanced" {if $current_buffer == 'balanced'}selected{/if}>Balanced (30ms buffer, neutral)</option>
                <option value="relaxed" {if $current_buffer == 'relaxed'}selected{/if}>Relaxed (80ms buffer, natural)</option>
                <option value="safe" {if $current_buffer == 'safe'}selected{/if}>Safe (160ms buffer, anti-underrun)</option>
                <option value="ultra" {if $current_buffer == 'ultra' || !$current_buffer}selected{/if}>Ultra Smooth (320ms buffer - 256k / Low Jitter)</option>
                <option value="deep" {if $current_buffer == 'deep'}selected{/if}>Deep Buffer (640ms / 512k - Vinyl Fluidity)</option>
            </select>
        </div>

        <div class="maestro-control-row">
            <label class="maestro-label">DSP Filter Architecture:</label>
            <select name="sox_filter" class="maestro-select-input">
                <optgroup label="── DIRECT AUDIO (Pure Stream) ──">
                    <option value="none" {if $current_filter == 'none'}selected{/if}>Direct Bit-Perfect (Disable All DSP Filters)</option>
                </optgroup>
                <optgroup label="── VINYL / LP SIMULATION (Analog Turntable) ──">
                    <option value="vinyl_vintage" {if $current_filter == 'vinyl_vintage' || $current_filter == 'min_l3'}selected{/if}>Vintage LP (MM Cartridge / Tube Phono Warmth)</option>
                    <option value="vinyl_modern" {if $current_filter == 'vinyl_modern' || $current_filter == 'arch_l3'}selected{/if}>Modern LP (High-End MC Cartridge / 3D Soundstage)</option>
                </optgroup>
                <optgroup label="── MINIMUM PHASE (Punchy Bass & Fast Transient) ──">
                    <option value="min_l1" {if $current_filter == 'min_l1' || !$current_filter}selected{/if}>Level 1: Fast Roll-off (Punchy Bass / Fast Transient)</option>
                    <option value="min_l2" {if $current_filter == 'min_l2'}selected{/if}>Level 2: Vocal & Punch (Forward Vocal / Firm Bass)</option>
                </optgroup>
                <optgroup label="── ARCHIMAGO HYBRID (Analog Warmth & Musicality) ──">
                    <option value="arch_l1" {if $current_filter == 'arch_l1'}selected{/if}>Level 1: Reference Audio (Balanced / High Fidelity)</option>
                    <option value="arch_l2" {if $current_filter == 'arch_l2'}selected{/if}>Level 2: Analog Warmth (Rich & Mellow / Sweet Vocal)</option>
                </optgroup>
            </select>
        </div>
    </div>
            </div>

            <div style="text-align: center; margin-top: 22px;">
                <button type="submit" name="action" value="submit" class="maestro-btn">Save Settings</button>
            </div>
        </form>
    </div>

    <!-- CARD 2: ALSA AUDIO SYSTEM DIAGNOSTICS ĐƯỢC ĐỊNH HÌNH CHUẨN CARD -->
    <div class="maestro-card">
        <div class="maestro-subtitle">ALSA Audio System Diagnostics</div>
        <pre class="maestro-diag-box">{$CardList}</pre>

        <div class="maestro-subtitle" style="margin-top: 20px;">Playback Guide</div>
        <div class="maestro-guide">
            <p style="margin: 4px 0;">* For <b>DSD</b>: Select <b>Native/DoP</b> (DSD Output Mode), <b>Native</b> (Max Sample Rate), and <b>Direct Bit-Perfect</b>.</p>
            <p style="margin: 4px 0;">* For <b>PCM</b>: Select <b>Disable DSD</b> (DSD Output Mode) when using Alternative Pitch Tunings.</p>
        </div>
    </div>
</div>

{include file="footer.tpl"}
