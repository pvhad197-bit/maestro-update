<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<link id="page_favicon" href="images/favicon.ico" rel="icon" type="image/x-icon" />
<title>Maestro</title>
<link rel="shortcut icon" href="images/favicon.ico" />
<style>
    body {
        background-color: #f8fafc;
        color: #1e293b;
        font-family: 'Segoe UI', Arial, sans-serif;
        margin: 0;
        padding: 0;
    }
    .top-bar {
        background: #ffffff;
        padding: 15px 50px;
        display: flex;
        align-items: center;
        justify-content: space-between;
        border-bottom: 2px solid #0284c7;
        box-shadow: 0 1px 3px rgba(0,0,0,0.05);
    }
    .logo-area img {
        height: 45px;
    }
    .slogan-text {
        color: #0284c7;
        font-weight: 600;
        font-size: 16px;
    }
    .nav-container {
        background-color: #f1f5f9;
        padding: 10px;
        display: flex;
        flex-wrap: nowrap;
        gap: 8px;
        justify-content: center;
        border-bottom: 1px solid #e2e8f0;
        overflow-x: auto;
    }
    .menu-item {
        display: flex;
        flex-direction: row;
        align-items: center;
        gap: 9px;
        background-color: #ffffff;
        padding: 12px 12px;
        border-radius: 6px;
        text-decoration: none;
        color: #475569;
        font-size: 13px;
        font-weight: 500;
        transition: all 0.2s ease;
        border: 1px solid #cbd5e1;
        white-space: nowrap;
        box-shadow: 0 1px 2px rgba(0,0,0,0.02);
    }
    .menu-item:hover {
        background-color: #0284c7;
        color: #ffffff;
        border-color: #0284c7;
        transform: translateY(-1px);
    }
    .menu-item img {
        width: 18px;
        height: 18px;
    }
    .main-content {
        padding: 40px 20px;
        max-width: 1000px;
        margin: 0 auto;
    }
    .main-content table {
        margin: 20px auto !important;
        background-color: #ffffff !important;
        color: #1e293b !important;
        border: 1px solid #cbd5e1 !important;
        border-radius: 8px;
        border-collapse: collapse;
        box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05);
    }
    .main-content td, .main-content th {
        color: #1e293b !important;
        border: 1px solid #e2e8f0 !important;
        padding: 10px 15px !important;
    }
    .main-content th {
        background-color: #f1f5f9 !important;
        font-weight: 600;
    }
</style>
<script src="/js/jquery.js" type="text/javascript"></script>
<script src="/js/jtip.js" type="text/javascript"></script>
</head>
<body>

<div class="top-bar">
    <div class="logo-left" style="flex: 1; display: flex; justify-content: flex-start;">
        <a href="http://adaudio.vn/"><img border="0" src="images/logo.png" style="height: 55px;"></a>
    </div>
    
    <div class="slogan-center" style="flex: 1; display: flex; justify-content: center; text-align: center;">
        <div class="slogan-text" style="color: #0284c7; font-weight: 600; font-size: 25px; white-space: nowrap;">
            THE HEART OF AUDIOPHILE SYSTEM
    </div>
    </div>
    
    <div class="logo-right" style="flex: 1; display: flex; justify-content: flex-end; align-items: center;">
        <img border="0" src="images/oem_logo.png" style="height: 55px; object-fit: contain;">
    </div>
</div>
<div class="nav-container">
{foreach from=$IconList key=IconId item=i}
    <a class="menu-item" href="{$i.link}" {if isset($i.newtab)} target="_blank" {/if} title="{if $i.name == 'VortexBox Upgrade'}Upgrade{else}{$i.name}{/if}">
        <img src="images/{$i.icon}">
        <span>{if $i.name == 'Extremo Player'}PureTone Player{elseif $i.name == 'VortexBox Upgrade'}Upgrade{else}{$i.name}{/if}</span>
    </a>

    {if $i.name == 'NAS Storage'}
    <a class="menu-item" href="/network.php" title="Network">
        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#0284c7" stroke-width="2.3" stroke-linecap="round" stroke-linejoin="round" style="margin-right: 6px;"><path d="M5 12.55a11 11 0 0 1 14.08 0"></path><path d="M1.42 9a16 16 0 0 1 21.16 0"></path><path d="M8.53 16.11a6 6 0 0 1 6.95 0"></path><line x1="12" y1="20" x2="12.01" y2="20"></line></svg>
        <span>Network</span>
    </a>
    {/if}
    {/foreach}
</div>

<div class="main-content">