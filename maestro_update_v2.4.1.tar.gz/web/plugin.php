<?php
// --- BẮT ĐẦU THEO DÕI ---
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $is_pk = false;
    $act = 'connect';
    $json = strtolower(json_encode($_POST));
    if (strpos($json, 'pikpak') !== false) {
        $is_pk = true;
        if (strpos($json, 'disconnect') !== false) $act = 'disconnect';
    }
    
    if ($is_pk) {
        if ($act === 'disconnect') {
            shell_exec("sudo /usr/local/bin/maestro-pikpak.sh web_disconnect");
        } else {
            $u = trim($_POST['pikpak_user'] ?? $_POST['email'] ?? $_POST['username'] ?? $_POST['account'] ?? '');
            $p_pass = trim($_POST['pikpak_pass'] ?? $_POST['password'] ?? $_POST['pass'] ?? '');
            if (!empty($u)) {
                shell_exec("sudo /usr/local/bin/maestro-pikpak.sh web_connect " . escapeshellarg($u) . " " . escapeshellarg($p_pass));
            }
        }
        header("Location: plugin.php");
        exit;
    }
}
// --- KẾT THÚC THEO DÕI ---







require_once 'libs/setup.php';

// 1. Kiểm tra trạng thái Tailscale
$ts_raw = shell_exec("tailscale status 2>&1");
$ts_ip = trim(shell_exec("tailscale ip -4 2>/dev/null"));
$ts_active = (!empty($ts_ip) && strpos($ts_raw, "Logged out") === false && strpos($ts_raw, "Tailscale is stopped") === false);
$ts_login_url = file_exists("/tmp/ts_login_url.txt") ? trim(file_get_contents("/tmp/ts_login_url.txt")) : "";

// 2. Kiểm tra trạng thái ZeroTier
$zt_raw = shell_exec("sudo /usr/bin/zerotier-cli listnetworks 2>&1");
$zt_active = false;
$zt_netid = "";
$zt_ip = "";
if (preg_match('/200 listnetworks (\w{16})\s+(\S+)\s+\S+\s+OK\s+(\S+)/', $zt_raw, $m)) {
    $zt_active = true;
    $zt_netid = $m[1];
    $zt_ip = explode('/', $m[3])[0];
}

// 3. Kiểm tra trạng thái WireGuard
$wg_raw = shell_exec("sudo /usr/bin/wg show wg0 2>&1");
$wg_active = (strpos($wg_raw, "interface: wg0") !== false);

// Xử lý các Form gửi lên
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'ts_generate') {
        @unlink("/tmp/ts_login_url.txt");
        shell_exec("sudo /usr/bin/tailscale down 2>/dev/null");
        shell_exec("sudo /usr/bin/tailscale up --reset > /tmp/ts_out.txt 2>&1 &");
        for ($i = 0; $i < 5; $i++) {
            sleep(1);
            $out = @file_get_contents("/tmp/ts_out.txt");
            if (preg_match('/(https:\/\/login\.tailscale\.com\/a\/[a-zA-Z0-9]+)/', $out, $matches)) {
                file_put_contents("/tmp/ts_login_url.txt", $matches[1]);
                break;
            }
        }
    } elseif ($action === 'ts_disconnect') {
        shell_exec("sudo /usr/bin/tailscale logout 2>/dev/null || sudo /usr/bin/tailscale down 2>/dev/null");
        @unlink("/tmp/ts_login_url.txt");
        @unlink("/tmp/ts_out.txt");
    } elseif ($action === 'zt_join') {
        $netid = preg_replace('/[^a-fA-F0-9]/', '', $_POST['zt_network_id'] ?? '');
        if (strlen($netid) === 16) {
            shell_exec("sudo /usr/bin/zerotier-cli join " . escapeshellarg($netid));
            sleep(2);
        }
    } elseif ($action === 'zt_leave') {
        $netid = preg_replace('/[^a-fA-F0-9]/', '', $_POST['zt_network_id'] ?? '');
        if (!empty($netid)) {
            shell_exec("sudo /usr/bin/zerotier-cli leave " . escapeshellarg($netid));
            sleep(1);
        }
    } elseif ($action === 'wg_upload' && isset($_FILES['wg_conf'])) {
        if ($_FILES['wg_conf']['error'] === UPLOAD_ERR_OK) {
            $tmp_path = $_FILES['wg_conf']['tmp_name'];
            shell_exec("sudo /usr/bin/wg-quick down wg0 2>/dev/null");
            shell_exec("sudo cp " . escapeshellarg($tmp_path) . " /etc/wireguard/wg0.conf");
            shell_exec("sudo chmod 600 /etc/wireguard/wg0.conf");
            shell_exec("sudo /usr/bin/wg-quick up wg0 2>/dev/null");
        }
    } elseif ($action === 'wg_down') {
        shell_exec("sudo /usr/bin/wg-quick down wg0 2>/dev/null");
    }

    header("Location: plugin.php");
    exit;
}

$smarty->assign('ts_active', $ts_active);
$smarty->assign('ts_ip', $ts_ip);
$smarty->assign('ts_login_url', $ts_login_url);

$smarty->assign('zt_active', $zt_active);
$smarty->assign('zt_netid', $zt_netid);
$smarty->assign('zt_ip', $zt_ip);

$smarty->assign('wg_active', $wg_active);
// --- XỬ LÝ PIKPAK CLOUD STORAGE ---
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $is_pk = false;
    $action = '';
    
    // Tìm tín hiệu của form WebDAV
    if (isset($_POST['pikpak_action'])) {
        $is_pk = true;
        $action = strtolower($_POST['pikpak_action']);
    } else {
        foreach ($_POST as $k => $v) {
            if (strpos(strtolower($k), 'pikpak') !== false || strpos(strtolower($v), 'connect') !== false) {
                $is_pk = true;
                $action = 'connect';
                break;
            }
        }
    }

    if ($is_pk) {
        if (strpos($action, 'disconnect') !== false) {
            @file_put_contents('/etc/maestro-pikpak.conf', '');
            shell_exec("sudo /usr/local/bin/maestro-pikpak.sh disconnect > /tmp/pikpak_sh.log 2>&1");
        } else {
            // Quét mọi biến có thể là tài khoản và mật khẩu
            $pk_user = trim($_POST['pikpak_user'] ?? $_POST['pikpak_email'] ?? $_POST['email'] ?? $_POST['username'] ?? $_POST['account'] ?? '');
            $pk_pass = trim($_POST['pikpak_pass'] ?? $_POST['pikpak_password'] ?? $_POST['password'] ?? $_POST['pass'] ?? '');
            
            // Ghi nhật ký bắt tay
            file_put_contents('/tmp/pikpak_web.log', "User: [$pk_user], Pass_len: " . strlen($pk_pass) . " | Raw POST: " . json_encode($_POST));
            
            if (!empty($pk_user) && !empty($pk_pass)) {
                @file_put_contents('/etc/maestro-pikpak.conf', $pk_user);
                shell_exec("sudo /usr/local/bin/maestro-pikpak.sh connect " . escapeshellarg($pk_user) . " " . escapeshellarg($pk_pass) . " > /tmp/pikpak_sh.log 2>&1");
            } else {
                file_put_contents('/tmp/pikpak_web.log', "
-> LỖI: Không tìm thấy User/Pass trong form!", FILE_APPEND);
            }
        }
        header("Location: plugin.php");
        exit;
    }
}

$pikpak_st = trim(shell_exec("sudo /usr/local/bin/maestro-pikpak.sh status 2>/dev/null"));
$is_pk_connected = ($pikpak_st === 'connected');

$pk_saved_user = '';
if (file_exists('/etc/maestro-pikpak.conf')) {
    $lines = file('/etc/maestro-pikpak.conf', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    $pk_saved_user = trim($lines[0] ?? '');
}

if (isset($smarty)) {
    $smarty->assign('PIKPAK_CONNECTED', $is_pk_connected);
    $smarty->assign('PIKPAK_USER', $pk_saved_user);
    $smarty->display('plugin.tpl');
}
