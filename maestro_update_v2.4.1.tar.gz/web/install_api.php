<?php
header('Content-Type: application/json');
$action = $_GET['action'] ?? '';

if ($action === 'list') {
    $out = shell_exec('sudo /usr/local/bin/maestro_web_install.sh list');
    $lines = array_filter(explode("\n", trim((string)$out)));
    $disks = [];
    foreach ($lines as $line) {
        $parts = preg_split('/\s+/', $line, 3);
        if (count($parts) >= 2) {
            $disks[] = ['dev' => $parts[0], 'size' => $parts[1], 'model' => $parts[2] ?? 'Internal SSD'];
        }
    }
    echo json_encode($disks);
    exit;
}

if ($action === 'run') {
    $target = escapeshellarg($_POST['target'] ?? '');
    if ($target) {
        shell_exec("sudo /usr/local/bin/maestro_web_install.sh run $target");
        echo json_encode(['status' => 'started']);
    } else {
        echo json_encode(['status' => 'error']);
    }
    exit;
}

if ($action === 'status') {
    $log = @file_get_contents('/tmp/maestro_install.log') ?: 'IDLE';
    $done = strpos($log, 'DONE') !== false;
    echo json_encode(['log' => $log, 'done' => $done]);
    exit;
}
