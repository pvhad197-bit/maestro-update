<?php
// Copyright (C) 2022-2026 by AD Audio
//

require '/var/www/html/libs/registry_fuctions.php';
require '/var/www/html/libs/multi_language.php';

echo "<p>";
echo _("This setting will mirror FLAC to mp3 for a CD when it is ripped.");
echo "</p>";

?>
