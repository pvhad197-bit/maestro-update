<?php
// Copyright (C) 2022-2026 by AD Audio
//

require '/var/www/html/libs/registry_fuctions.php';
require '/var/www/html/libs/multi_language.php';

echo "<p>";
echo _("The VortexBox DLNA server allows your to access your media from DLNA complient device such as Windows 7 or PS3.");
echo "</p>";

?>
