<?php
// Copyright (C) 2022-2026 by AD Audio
//

require '/var/www/html/libs/registry_fuctions.php';
require '/var/www/html/libs/multi_language.php';

echo "<p>";
echo _('The VortexBox CD/DVD Autoripper rips your DVDs and CDs and converts them to files you can play back on your player. If the ripper is stuck ripping a disc you can restart is with the "Restart Autoripper" button.  If you have imported your own music use the "Get CD Cover Art" button to get cover art for your music from Amazon. If there is am existing cover.jpg it will not be over written.');
echo "</p>";
echo "<p>";
echo _('By default the DVD Autoripper will rip the longest track. This is usually the main movie. If you want to rip all tracks that are longer then a certain time you can select that option.');
echo "</p>";

?>
