<?php
// Copyright (C) 2022-2026 by AD Audio
//

require '/var/www/html/libs/registry_fuctions.php';
require '/var/www/html/libs/multi_language.php';

echo "<p>";
echo _("This will be the MAC address of your VortexBox player. Leave this field blank and a random MAC address will be assigned to this player. Use the format XX:XX:XX:XX:XX:XX");
echo "</p>";

?>
