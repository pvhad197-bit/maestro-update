<?php
// Copyright (C) 2022-2026 by AD Audio
//

require '/var/www/html/libs/registry_fuctions.php';
require '/var/www/html/libs/multi_language.php';

echo '<p>';
echo _("Check this box if you want to be able to control the volume of this player from your VortexBox. Leave this disabled if you have volume control on the amp your are connected to. Uncheck this for bit perfect sound to a USB or S/PDIF DAC.");
echo '</p>';

?>
