<?php
// Copyright (C) 2022-2026 by AD Audio
//

require '/var/www/html/libs/registry_fuctions.php';
require '/var/www/html/libs/multi_language.php';

echo "<p>";
echo _("The default gateway is the IP address of your router or cable modem.");
echo "</p>";

?>
