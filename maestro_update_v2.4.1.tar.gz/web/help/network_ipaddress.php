<?php
// Copyright (C) 2022-2026 by AD Audio
//

require '/var/www/html/libs/registry_fuctions.php';
require '/var/www/html/libs/multi_language.php';

echo "<p>";
echo _("The IP  address is the address you use to access your VortexBox. It needs to be different than any address on your network. The IP address should be of the format xxx.xxx.xxx.xxx the xxx represents the numbers  between 1 and 255.");
echo "</p>";

?>
