<?php
// Copyright (C) 2022-2026 by AD Audio
//

require '/var/www/html/libs/registry_fuctions.php';
require '/var/www/html/libs/multi_language.php';

echo "<p>";
echo _("Description of the VortexBox DLNA server that will show up on DLNA clients.");
echo "</p>";

?>
