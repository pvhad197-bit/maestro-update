<?php
// Copyright (C) 2022-2026 by AD Audio
//

require '/var/www/html/libs/registry_fuctions.php';
require '/var/www/html/libs/multi_language.php';

echo "<p>";
echo _("The DNS address is the address of your DNS server. Leave these blank and the fast OpenDNS servers will be selected.");
echo "</p>";

?>
