<?php
// Copyright (C) 2022-2026 by AD Audio
//

require '/var/www/html/libs/registry_fuctions.php';
require '/var/www/html/libs/multi_language.php';

echo "<p>";
echo _("This is the name of your VortexBox on your network. You can access your VortexBox by typing http://Name (ie http://VortexBox).");
echo "</p>";

?>
