<?php
// Copyright (C) 2022-2026 by AD Audio
//

require '/var/www/html/libs/registry_fuctions.php';
require '/var/www/html/libs/multi_language.php';

echo "<p>";
echo _("You can select DHCP to get an IP address assigned by your router or Cable modem. If you select Static address make sure you fill in all the information correctly or your VortexBox may be inaccessible on your network.");
echo "</p>";

?>
