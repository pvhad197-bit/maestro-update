<?php
// Copyright (C) 2022-2026 by AD Audio
//

require '/var/www/html/libs/registry_fuctions.php';
require '/var/www/html/libs/multi_language.php';

echo "<p>";
echo _("\"Start Upgrade\" will download the latest code from the VortexBox server and also the latest Linux packages. If you interested in new features you should run this once in a while.");
echo "<br>";
echo _("You can also add new software packages to your VortexBox using the Package manager.");
echo "</p>";

?>
