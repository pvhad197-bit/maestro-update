<?php
// Copyright (C) 2022-2026 by AD Audio
//

require '/var/www/html/libs/registry_fuctions.php';
require '/var/www/html/libs/multi_language.php';

echo "<p>";
echo _("This is the name of your VortexBox player. It will appear in the player selector as this name.");
echo "</p>";

?>
