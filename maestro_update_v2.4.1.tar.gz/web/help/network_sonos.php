<?php
// Copyright (C) 2022-2026 by AD Audio
//

require '/var/www/html/libs/registry_fuctions.php';
require '/var/www/html/libs/multi_language.php';

echo "<p>";
echo _("Sonos Media players need top level shares to work properly. This will make a top level share for your mp3 and FLAC libraries. It will also enable the Sonos web user interface in the VortexBox GUI.");
echo "</p>";

?>
