<?php
// Copyright (C) 2022-2026 by AD Audio
//

require '/var/www/html/libs/registry_fuctions.php';
require '/var/www/html/libs/multi_language.php';

echo "<p>";
echo _("FLAC mirror allows you to convert your FLAC files to other formats. VortexBox currently supports mp3 files and mp4 (Apple lossless m4a) files.  You can start a conversion and FLAC mirror will convent all your FLAC files to the desired format. The next time you start the mirror only the new FLAC files will be mirrored.");
echo "</p>";

?>
