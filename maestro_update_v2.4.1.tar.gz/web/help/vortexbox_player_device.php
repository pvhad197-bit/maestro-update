<?php
// Copyright (C) 2022-2026 by AD Audio
//

require '/var/www/html/libs/registry_fuctions.php';
require '/var/www/html/libs/multi_language.php';

echo "<p>";
echo _("This is the ALSA device name of your player. You have a few options here.");
echo "</p>";
echo "<p>";
echo _("Default - this will select the default Audio device on your system.");
echo "</p>";
echo "<p>";
echo _("plughw:X,X - this will select the audio device with that device number and port number.");
echo "</p>";
echo "<p>";
echo _("An exmaple device is plughw:0,0 this is usually the default audio device on your system.");
echo "</p>";
echo "<p>";
echo _("You can use the information listed at the bottom of this page to select the device number and port number for your device.");
echo "</p>";

?>
