<?php
// Copyright (C) 2022-2026 by AD Audio
//

require '/var/www/html/libs/registry_fuctions.php';
require '/var/www/html/libs/multi_language.php';

echo "<p>";
echo _("This setting will embed cover art into your mp3 files. This is useful for programs such as iTunes that require embeded cover art.");
echo "</p>";

?>
