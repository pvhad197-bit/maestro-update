<?php
// Copyright (C) 2022-2026 by AD Audio
//

require '/var/www/html/libs/registry_fuctions.php';
require '/var/www/html/libs/multi_language.php';

echo "<p>";
echo _("mp3 is a lossy compression. You can trade sound quality for file size. The best quality is 320kbit/s fix bitrate. 320kbit/s fix is very high quality but still a decent size. 160kbit/s variable bitrate is good for playback devices with limited memory or streaming over a low bandwidth internet connection.");
echo "</p>";

?>
