<?php
// Copyright (C) 2022-2026 by AD Audio
//

require '/var/www/html/libs/registry_fuctions.php';
require '/var/www/html/libs/multi_language.php';

echo "<p>";
echo _("This setting will configure the number of threads to use for FLAC-to-mp3 mirroring. Typically you should set this to the number of processors (or cores) on your system.");
echo "</p>";

?>
