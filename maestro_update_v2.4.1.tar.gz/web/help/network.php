<?php
// Copyright (C) 2022-2026 by AD Audio
//

require '/var/www/html/libs/registry_fuctions.php';
require '/var/www/html/libs/multi_language.php';

echo "<p>";
echo _("The network configuration page allows you to configure an IP address for your system. You can use DHCP or assign a static IP address.");
echo "</p>";

?>
