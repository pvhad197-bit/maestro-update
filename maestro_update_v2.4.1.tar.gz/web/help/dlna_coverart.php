<?php
// Copyright (C) 2022-2026 by AD Audio
//

require '/var/www/html/libs/registry_fuctions.php';
require '/var/www/html/libs/multi_language.php';

echo "<p>";
echo _("Resize the cover art to this size if it's larger. Example 500 would resize to 500px X 500px.");
echo "</p>";

?>
