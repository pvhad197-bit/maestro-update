<?php
// Copyright (C) 2022-2026 by AD Audio
//

require '/var/www/html/libs/registry_fuctions.php';
require '/var/www/html/libs/multi_language.php';

$mac = trim(shell_exec('/usr/local/bin/get-maestro-mac.sh'));
echo _("The system configuration screen lets you change system defaults such as Time Zone and default temperature format. You can also reboot or restart your VortexBox. The Service Manager to start and stop services if they are not working.");
echo "<br>";
$mac = trim(shell_exec('/usr/local/bin/get-maestro-mac.sh'));
echo "</p>";

?>
