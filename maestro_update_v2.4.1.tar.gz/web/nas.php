<?php
// Copyright (C) 2022-2026 by AD Audio

require_once 'libs/setup.php';
if (file_exists('libs/network_functions.php')) { require_once 'libs/network_functions.php'; }

$config_file = "/var/www/html/config/nas_creds.conf";
$trigger_file = "/var/www/html/config/nas_reload.trigger";
$status_msg = "";

$_action = isset($_REQUEST['action']) ? $_REQUEST['action'] : 'default';

// 1. Xử lý ngắt kết nối
if ($_action == 'disconnect') {
    @file_put_contents($config_file, '');
    @touch($trigger_file);
    @chmod($trigger_file, 0777);
    shell_exec("sudo /usr/bin/umount -l -f /storage/nas_music 2>/dev/null");
    sleep(1);
    $status_msg = "disconnected";
}

// 2. Xử lý kết nối mới
if ($_action == 'submit') {
    $nas_ip = trim($_POST['nas_ip'] ?? '');
    $nas_folder = trim($_POST['nas_folder'] ?? '');
    $nas_user = trim($_POST['nas_user'] ?? '');
    $nas_pass = trim($_POST['nas_pass'] ?? '');

    if (!empty($nas_ip) && !empty($nas_folder)) {
        // Kiểm tra ping tới IP mục tiêu (chờ tối đa 1.5 giây)
        $ping_res = trim(shell_exec("ping -c 1 -W 2 " . escapeshellarg($nas_ip) . " >/dev/null 2>&1; echo $?"));
        
        if ($ping_res === "0") {
            // Ping thành công: Gỡ mount cũ trước khi mount địa chỉ mới
            shell_exec("sudo /usr/bin/umount -l -f /storage/nas_music 2>/dev/null");
            
            $config_data = "NAS_IP=\"$nas_ip\"\nNAS_FOLDER=\"$nas_folder\"\nNAS_USER=\"$nas_user\"\nNAS_PASS=\"$nas_pass\"\n";
            file_put_contents($config_file, $config_data);
            chmod($config_file, 0777);
            
            touch($trigger_file);
            chmod($trigger_file, 0777);
            
            // Đợi daemon kết nối
            sleep(2);
            $status_msg = "success";
        } else {
            // Ping thất bại (sai IP hoặc NAS tắt/rút dây): Không lưu cấu hình và gỡ mount luôn
            $status_msg = "ip_error";
            @file_put_contents($config_file, '');
            @touch($trigger_file);
            shell_exec("sudo /usr/bin/umount -l -f /storage/nas_music 2>/dev/null");
        }
    } else {
        $status_msg = "error";
    }
}

// 3. Đọc lại cấu hình đã lưu
$nas_info = array('nas_ip' => '', 'nas_folder' => '', 'nas_user' => '', 'nas_pass' => '');
if (file_exists($config_file)) {
    $lines = file($config_file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($lines as $line) {
        if (preg_match('/^NAS_(.+?)="(.+?)"$/', $line, $matches)) {
            $key = strtolower($matches[1]);
            $nas_info[$key] = $matches[2];
        }
    }
}

// 4. Kiểm tra trạng thái mount thực tế từ hệ điều hành
$mounts = @file_get_contents('/proc/mounts');
$is_mounted = ($mounts !== false && strpos($mounts, '/storage/nas_music') !== false);

// Nếu nhập IP sai, ép trạng thái hiển thị Not Connected
if ($status_msg === 'ip_error') {
    $is_mounted = false;
    $nas_info['nas_ip'] = $_POST['nas_ip'] ?? '';
    $nas_info['nas_folder'] = $_POST['nas_folder'] ?? '';
    $nas_info['nas_user'] = $_POST['nas_user'] ?? '';
    $nas_info['nas_pass'] = $_POST['nas_pass'] ?? '';
}

$smarty->assign('status_msg', $status_msg);
$smarty->assign('is_mounted', $is_mounted);
foreach ($nas_info as $key => $value) {
    $smarty->assign($key, trim($value));
}

if (file_exists("iconlist.php")) {
    include_once("iconlist.php");
}

$smarty->display('nas.tpl');
?>
