<?php
//

$availableLanguages = array(
'en_EN' => 'English'
);

?>

