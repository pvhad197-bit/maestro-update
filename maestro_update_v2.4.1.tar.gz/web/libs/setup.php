<?php
// Copyright (C) 2022-2026 by AD Audio
//

$startTime = microtime(TRUE);

// setup Smarty
require_once 'smarty/libs/Smarty.class.php';
$smarty = new Smarty;
$smarty->setTemplateDir('/var/www/html/templates');
$smarty->setCompileDir('/var/www/html/templates_c');
$smarty->setCacheDir('/var/www/html/cache');
$smarty->setConfigDir('/var/www/html/configs');

$smarty->caching = 0;
$pageLoadTest = 0;

$smarty->compile_check = true;
$smarty->debugging = false;

$menu_items = array (
	"Home" 		=> "home.php"
						
);
// Smarty Template functions
require_once 'libs/smarty_functions.php';

// Text processing functions
require_once 'libs/text_functions.php';

// Fixed varibles
require_once 'libs/vars.php';

// Registry functions
require_once 'libs/registry_fuctions.php';

// Language translation functions
require_once 'libs/multi_language.php';

// Icon list for GUI
require_once 'libs/iconlist.php';

function pageLoadTest()
{
	global $pageLoadTest, $startTime;
	if($pageLoadTest == 1) {
		$endTime = microtime(TRUE);
		$timeTaken = $endTime - $startTime;
		$timeTaken = round($timeTaken,5);
		echo 'Page generated in '.$timeTaken.' seconds.';
	}
}
?>