<?php
// Copyright (C) 2026 by AD Audio
//

function do_translation ($params, $content)
{
  if (isset($content)) {
	$translation = gettext($content);
    return $translation;
  }
}
$smarty->registerPlugin("block","t", "do_translation");


?>

