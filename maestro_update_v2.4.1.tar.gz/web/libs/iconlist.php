<?php
// Copyright (C) 2022-2026 by AD Audio
//
$ipaddress = getSysVar('IPaddress');

$loacation_count = 0;
$icon_array[] = array('location' => $loacation_count += 80, 'name' => _('Home'), 'icon' => 'home.png', 'link' => '/');
$icon_array[] = array('location' => $loacation_count += 80, 'name' => _('Server Selection'), 'icon' => 'server.png', 'link' => '/server.php');
$loacation_count += 10;

// Check to see if Squeezelite is installed
if (file_exists('/usr/bin/squeezelite')) {
	$icon_array[] = array('location' => $loacation_count += 80, 'name' => 'HW Selection', 'icon' => 'DSP.png', 'link' => '/hw.php');
	$loacation_count += 10;
}

// Check to see if ripit is installed
if (file_exists("/usr/bin/ripit")) {
	$icon_array[] = array('location' => $loacation_count += 80, 'name' => 'CD Ripper', 'icon' => 'cddrive.png', 'link' => '/ripstatus.php');
	$loacation_count += 10;
}
$icon_array[] = array('location' => $loacation_count += 80, 'name' => 'NAS Storage', 'icon' => 'nas.png', 'link' => '/nas.php');
$icon_array[] = array('location' => $loacation_count += 80, 'name' => 'Remote Access', 'icon' => 'remote.png', 'link' => '/plugin.php');
$loacation_count += 10;

$loacation_count += 10;
	

$icon_array[] = array('location' => $loacation_count += 80, 'name' => 'LMS Remote', 'icon' => 'lms.png', 'link' => 'http://' . (!empty($_SERVER['HTTP_HOST']) ? explode(':', $_SERVER['HTTP_HOST'])[0] : $ipaddress) . ':9000', 'newtab' => '1');
$loacation_count += 10;

$smarty->assign('IconList',$icon_array);

?>
