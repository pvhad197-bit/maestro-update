<?php
//Copyright (C) 2026 by AD Audio
// Dump all registry
function dumpreg($section)
{	
	check_reg($section);
	$config = array();
	$configfile = 'config/'.$section.'.cfg';
	$config = unserialize(file_get_contents($configfile));
	print_r($config);
}

// get a key from the registry
function getreg($section, $key, $count='')
{	
	check_reg($section);
	$config = array();
	$configfile = 'config/'.$section.'.cfg';
	$config = unserialize(file_get_contents($configfile));
	if ($count =='') {
		$retval = $config[$key];
	} else {
		$retval = $config[$count][$key];
	}
    return $retval;
}

// set key in the registry
function putreg($section, $key, $value, $count='')
{
	check_reg($section);
	$config = array();
	$configfile = 'config/'.$section.'.cfg';
	$config = unserialize(file_get_contents($configfile));
	if ($count =='') {
		$config[$key] = $value;
	} else {
		$config[$count][$key] = $value;
	}
	
	$fp = fopen($configfile,'w');
	fwrite($fp,serialize($config));
	fclose($fp);
}

function check_reg($section)
{	
	$configfile = 'config/'.$section.'.cfg';

	$default = array();

// if registry.cfg file dosn't exist create it with the defaults		
	if (! file_exists($configfile)) {
	  $fp = fopen($configfile,'w');
	  fwrite($fp,serialize($default));
	  fclose($fp);
	} 
}

?>

