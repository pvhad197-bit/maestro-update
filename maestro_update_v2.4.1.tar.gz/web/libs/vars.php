<?php
// Copyright (C) 2022-2026 by AD Audio
//

// Set the PHP timezone. We get a lot of errors if we don't do this.
$CurrentTimeZone = exec("/usr/bin/timedatectl | grep 'Timezone:' |  awk '{ print $2 }'");
date_default_timezone_set($CurrentTimeZone);

// Avalible audio services
$serviceList = array(	'squeezelite0' => 'SqueezeLite',
						'shairport' => 'AirPlay',
						'gmediarender' => 'DLNA',
						'mpd' => 'MPD'); 

// Get a system varables
function getSysVar($sysVar)
{	
  switch ($sysVar) {
    case 'dateTimeNow':
		$sysVarValue = date("m/d/Y g:i:s A", time());
        break;
    case 'Hostname':
		$sysVarValue = trim(exec('/usr/bin/hostname -s'));
        break;
    case 'MacAddress':
		$sysVarValue = strtoupper(fget_contents('/sys/class/net/eth0/address'));
        break;
	case 'IPaddress':
		$sysVarValue = exec("/sbin/ifconfig eth0 | grep inet | awk '{print $2}' | sed  's/addr://' | head -1");
		if ($sysVarValue == "") { $sysVarValue = exec("/sbin/ifconfig | grep inet | awk '{print $2}' | sed  's/addr://' | head -1");}
        break;
    case 'SqueezeLiteVersion':
		$sysVarValue = exec("/usr/bin/squeezelite -h | head -1 | gawk '{print $2}' | sed -e 's/,$//'");
		break;
    case 'MPDVersion':
		$sysVarValue = trim(exec("/usr/bin/mpd -V | head -1 | gawk '{print $6}'"));
        break;
    case 'DLNAVersion':
		$sysVarValue = trim(exec("/usr/bin/gmediarender --version | head -1 | gawk '{print $3}'"));
        break;
	case 'FedoraVersion':
		$sysVarValue = fget_contents('/etc/fedora-release');
        break;	
    case 'VortexBoxVersion':
		$sysVarValue = fget_contents('/etc/vortexbox/vortexbox-version');
        break;
    case 'audioStatus':
		$sysVarValue = fget_contents('/proc/asound/card0/stream0');
		if ($sysVarValue == 'UNKNOWN') {
			$sysVarValue = "Not avalible.";
		} else {
			$sysVarValue = nl2br($sysVarValue);
		}
        break;
    case 'audioHardwareStatus':
		$sysVarValue = fget_contents('/proc/asound/card0/pcm0p/sub0/hw_params');
		if ($sysVarValue == 'UNKNOWN') {
			$sysVarValue = "Not avalible.";
		} else {
			$sysVarValue = nl2br($sysVarValue);
		}
        break;
    case 'EnabledService':
		$sysVarValue = fget_contents('/etc/vamp/start_player');
        break;
    case 'storageMount':
		$storageInfo = exec('/usr/bin/mount | grep /storage');
		if ($storageInfo == '')
		{
			$sysVarValue = 'No NFS mount.';
		} else {
			$storageInfoIP = explode(':', $storageInfo);
			$sysVarValue = trim($storageInfoIP[0]);
		}
        break;		
	default:
       $sysVarValue = 'ERROR: '.$sysVar.' does not exist.';		
  }
  return $sysVarValue;
}

// Get Service status information
function serviceStatus($service)
{
	$rawStatus = trim(exec('/usr/bin/systemctl status '.$service.' | grep Active:'));
	$Status = explode(' ', $rawStatus);
	switch ($Status[1]) {
      case 'active':
		$serviceStatus = '<span class="label label-success">Active</span>';
        break;
      case 'inactive':
		$serviceStatus = '<span class="label label-important">Stopped</span>';
        break;		
	  default:
       $serviceStatus = '<span class="label">UNKNOWN</span>';		
	}		
	return $serviceStatus;
}

// --- MAESTRO DYNAMIC NETWORK DETECTION (LAN PRIORITY > WIFI) ---
$lan_found = false;
$nic = 'eth0';
$ip  = 'Not Connected';
$first_lan  = '';
$first_wifi = '';

// 1. Quét các cổng LAN vật lý (loại trừ ảo và wifi)
foreach (glob('/sys/class/net/*') as $dev_path) {
    $dev = basename($dev_path);
    if ($dev === 'lo' || !is_dir("$dev_path/device")) continue;
    if (is_dir("$dev_path/wireless") || is_dir("$dev_path/phy80211")) continue;
    if (trim(@file_get_contents("$dev_path/type")) !== '1') continue;

    $dev_ip = trim(shell_exec("ip -4 -o addr show " . escapeshellarg($dev) . " 2>/dev/null | awk '{print \$4}' | cut -d/ -f1 | head -n 1"));
    if (!empty($dev_ip)) {
        $nic = $dev;
        $ip  = $dev_ip;
        $lan_found = true;
        break;
    } elseif (empty($first_lan)) {
        $first_lan = $dev;
    }
}

// 2. Nếu LAN chưa cắm mạng hoặc không có IP -> tự động nhận Wi-Fi
if (!$lan_found) {
    foreach (glob('/sys/class/net/*') as $dev_path) {
        $dev = basename($dev_path);
        if (is_dir("$dev_path/wireless") || is_dir("$dev_path/phy80211")) {
            $dev_ip = trim(shell_exec("ip -4 -o addr show " . escapeshellarg($dev) . " 2>/dev/null | awk '{print \$4}' | cut -d/ -f1 | head -n 1"));
            if (!empty($dev_ip)) {
                $nic = $dev;
                $ip  = $dev_ip;
                break;
            } elseif (empty($first_wifi)) {
                $first_wifi = $dev;
            }
        }
    }
    if ($ip === 'Not Connected') {
        $nic = !empty($first_lan) ? $first_lan : (!empty($first_wifi) ? $first_wifi : 'eth0');
    }
}

// 3. Địa chỉ Hardware MAC định danh bản quyền (luôn lấy theo card mạng LAN cố định)
$mac = trim(shell_exec('/usr/local/bin/get-maestro-mac.sh 2>/dev/null'));
if (empty($mac)) {
    $mac = strtoupper(trim(@file_get_contents("/sys/class/net/$nic/address")));
}

if (isset($smarty)) {
    $smarty->assign('nic', $nic);
    $smarty->assign('ip', $ip);
    $smarty->assign('mac', $mac);
}
// --- END MAESTRO NETWORK DETECTION ---









// === MAESTRO STORAGE & DRIVES SCANNER (SATA / NVME / USB / NAS) ===
$drives_list = [];
$tracked_mounts = [];

// 1. Phân vùng hệ thống chính /storage
$df_st = shell_exec("df -h /storage 2>/dev/null | tail -n 1");
if ($df_st) {
    $p = preg_split('/\s+/', trim($df_st));
    if (count($p) >= 5) {
        $drives_list[] = [
            'name'    => '/storage',
            'size'    => $p[1],
            'used'    => $p[2],
            'avail'   => $p[3],
            'percent' => $p[4]
        ];
        $tracked_mounts['/storage'] = true;
    }
}

// DANH SÁCH PHÂN VÙNG HỆ THỐNG OS BẮT BUỘC LOẠI TRỪ KHỎI KHO NHẠC
$system_blacklist = ['/', '/home', '/root', '/boot', '/var', '/tmp', '/usr', '/opt', '/etc', '/srv', '/run', '/storage'];

// 2. Quét TẤT CẢ các ổ cứng vật lý gắn trong/ngoài (SATA SSD/HDD, NVMe M.2, USB)
$block_mounts = shell_exec("df -h -P 2>/dev/null | grep -E '^/dev/(sd|nvme)'");
if ($block_mounts) {
    foreach (explode("\n", trim($block_mounts)) as $line) {
        $parts = preg_split('/\s+/', trim($line));
        if (count($parts) >= 6) {
            $dev_node = $parts[0];
            $mount_pt = $parts[5];
            
            // Bỏ qua nếu là phân vùng hệ thống (/home, /boot, /, /var...)
            if (in_array($mount_pt, $system_blacklist)) continue;
            if (strpos($mount_pt, '/boot') === 0 || strpos($mount_pt, '/var') === 0 || strpos($mount_pt, '/run') === 0) continue;
            
            if (!isset($tracked_mounts[$mount_pt])) {
                $display_name = basename($mount_pt);
                if (empty($display_name) || $display_name === '/') {
                    $display_name = basename($dev_node);
                }
                
                $drives_list[] = [
                    'name'    => $display_name,
                    'size'    => $parts[1],
                    'used'    => $parts[2],
                    'avail'   => $parts[3],
                    'percent' => $parts[4]
                ];
                $tracked_mounts[$mount_pt] = true;
            }
        }
    }
}

// 3. Quét ổ mạng NAS / WebDAV (/storage/nas_music/*) - CHỈ KHI KẾT NỐI THỰC SỰ
$nas_dirs = glob('/storage/nas_music/*', GLOB_ONLYDIR);
if ($nas_dirs) {
    foreach ($nas_dirs as $dir) {
        $is_mount = trim(shell_exec("mountpoint -q " . escapeshellarg($dir) . " && echo 1 || echo 0"));
        if ($is_mount === '1') {
            $df_n = shell_exec("df -h " . escapeshellarg($dir) . " 2>/dev/null | tail -n 1");
            if ($df_n) {
                $p = preg_split('/\s+/', trim($df_n));
                if (count($p) >= 5) {
                    $drives_list[] = [
                        'name'    => basename($dir),
                        'size'    => $p[1],
                        'used'    => $p[2],
                        'avail'   => $p[3],
                        'percent' => $p[4]
                    ];
                }
            }
        }
    }
}

// Đồng bộ biến Smarty: LAN_NIC và NIC đều thống nhất theo card $nic thực tế
if (isset($smarty)) {
    $smarty->assign('DRIVES', $drives_list);
    $smarty->assign('drives', $drives_list);
    
// Quy chuẩn tên card hiển thị lên giao diện
$display_nic = 'eth0';
if (isset($nic)) {
    if (strpos($nic, 'wl') === 0) {
        $display_nic = 'wlan0';
    } else {
        $display_nic = 'eth0';
    }
}

$smarty->assign('NIC', (isset($nic) && strpos($nic, 'wl') === 0 ? 'wlan0' : 'eth0'));
$smarty->assign('nic', $display_nic);
    $smarty->assign('LAN_NIC', $nic ?? 'eno1');
    $smarty->assign('IPADDRESS', $ip ?? 'Not Connected');
    $smarty->assign('MACADDRESS', $mac ?? '');
}



$net_raw = shell_exec('/usr/local/bin/get-maestro-network.sh 2>/dev/null');
$net_info = json_decode($net_raw, true);
$nic = $net_info['nic'] ?? 'wlan0';
$ip  = $net_info['ip'] ?? 'Not Connected';
$mac = $net_info['mac'] ?? '1C:69:7A:A2:B9:C2';

if (isset($smarty)) {
    $smarty->assign('NIC', $nic);
    $smarty->assign('LAN_NIC', $nic);
    $smarty->assign('IPADDRESS', $ip);
    $smarty->assign('MACADDRESS', $mac);
}


// === MAESTRO SMART IP FILTER ===
$active_net = trim(shell_exec('/usr/local/bin/get-active-ip.sh 2>/dev/null'));
if ($active_net && strpos($active_net, '|') !== false) {
    list($active_nic, $active_ip) = explode('|', $active_net);
    $smarty->assign('NIC', $active_nic);
    $smarty->assign('IPADDRESS', $active_ip);
}
// ===============================
