<?php
if (!function_exists('each')) {
    function each(&$array) {
        $key = key($array);
        if ($key === null) {
            return false;
        }
        $val = current($array);
        next($array);
        return [
            1 => $val,
            'value' => $val,
            0 => $key,
            'key' => $key
        ];
    }
}
