<?php
// Copyright (C) 2013 Small Green Computer
//

$avalibleLanguages = array(
'en_EN' => 'English'
);

?>

