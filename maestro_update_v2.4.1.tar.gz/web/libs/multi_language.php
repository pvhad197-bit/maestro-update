<?php
//Copyright (C) 2026 by AD Audio
//

// Set up Language
$directory = "./i18n";
$domain = 'VortexBox';
$localeLanguage = getreg('System', 'Language');

setlocale( LC_MESSAGES, $localeLanguage);
bindtextdomain($domain, $directory);
textdomain($domain);
bind_textdomain_codeset($domain, 'UTF-8');

?>