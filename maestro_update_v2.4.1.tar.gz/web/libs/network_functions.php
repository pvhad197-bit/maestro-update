<?php
// Copyright (C) 2022-2026 by AD Audio
//
function get_system_info(){

$private_network_info = array();
$private_system_info = array(
'UUID' => '',
'SYSNAME' => '',
'WORKGROUP' => '',
'BOOTPROTO' => '',
'IPADDR' => '',
'NETMASK' => '',
'GATEWAY' => '',
'DNS1' => '',
'DNS2' => '',
'DNS3' => '',
'HWADDR' => ''
);


//----------------------------------------------
// Get Network info
	$lines = file('/etc/sysconfig/network-scripts/ifcfg-eth0');
	
    foreach ($lines as $line_num=>$line) {
  if ( ! preg_match("/#.*/", $line) ) {
	# Contains non-whitespace?
	if ( preg_match("/\S/", $line) ) {
	list( $key, $value ) = explode( "=", trim( $line ), 2);
	$config[$key] = str_replace('"', '', $value);
	  if ( isset($private_system_info[$key])) {
		$private_system_info[$key] = trim($config[$key]);
	 }
	}
  }
 }
//----------------------------------------------
unset($lines);

$private_system_info['HWADDR'] = getSysVar('MacAddress');
$private_system_info['SYSNAME'] = getSysVar('Hostname');
$private_system_info['WORKGROUP'] = smbWorkgroup();

return $private_system_info;
}


//////////////////////////////////////////////
// smbWorkgroup
// Get the SMB Workgroup name
//////////////////////////////////////////////
function smbWorkgroup()
{
	$lines = file('/etc/samba/smb.conf');
	$smblines = array();

	foreach ($lines as $line_num=>$line) {
		if ( ! preg_match("/#.*/", $line) ) {
		# Contains non-whitespace?
		if ( preg_match("/\S/", $line) ) {
		if (preg_match('/=/',$line)) {
			list( $key, $value ) = explode( "=", trim( $line ), 2);
			$smblines[trim($key)] = trim($value);		
		}
		}
	  }
	}

	return $smblines['workgroup'];
}

//////////////////////////////////////////////
// write_system_info
// write network and system name
//////////////////////////////////////////////

function write_system_info($private_system_info){

  if (empty($private_system_info['DNS1'])) { 
	$private_system_info['DNS1'] = "208.67.222.222";
	$private_system_info['DNS2'] = "208.67.220.220";
  }
  
  if ($fp = fopen('/var/www/html/config/ifcfg-eth0.new', 'w')) {
	fwrite($fp, "# Created by Sonicorbiter web admin on ".getSysVar('dateTimeNow')."\n");
	  if ($private_system_info['BOOTPROTO'] == 'none') {
		fwrite($fp, 'UUID='.$private_system_info['UUID']."\n");
		fwrite($fp, "DEVICE=eth0\n");
		fwrite($fp, "BOOTPROTO=none\n");		
		fwrite($fp, "ONBOOT=yes\n");
		fwrite($fp, "HWADDR=".$private_system_info['HWADDR']."\n");		
		fwrite($fp, "TYPE=Ethernet\n");
		fwrite($fp, "DEFROUTE=yes\n");
		fwrite($fp, "PEERROUTES=yes\n");
		fwrite($fp, "IPADDR=".$private_system_info['IPADDR']."\n");
		fwrite($fp, "NETMASK=".$private_system_info['NETMASK']."\n");
		fwrite($fp, "GATEWAY=".$private_system_info['GATEWAY']."\n");
		fwrite($fp, "DNS1=".$private_system_info['DNS1']."\n");	
		if (! empty($private_system_info['DNS2'])) { fwrite($fp, "DNS2=".$private_system_info['DNS2']."\n"); }
		if (! empty($private_system_info['DNS3'])) { fwrite($fp, "DNS3=".$private_system_info['DNS3']."\n"); }	
	  } else {
		fwrite($fp, 'UUID='.$private_system_info['UUID']."\n");
		fwrite($fp, "DEVICE=eth0\n");
		fwrite($fp, "HWADDR=".$private_system_info['HWADDR']."\n");
		fwrite($fp, "BOOTPROTO=dhcp\n");		
		fwrite($fp, "ONBOOT=yes\n");
	  }

	} else {
		echo 'Config file unwritable... '; 
  }
  $SYSNAME = $private_system_info['SYSNAME'];
  $WORKGROUP = $private_system_info['WORKGROUP'];
  
  exec("sudo /opt/maestro/setup_network.sh $SYSNAME $WORKGROUP");
  exec("sudo /opt/maestro/doaction.sh Reboot & >/dev/null 2>&1");
}
?>

