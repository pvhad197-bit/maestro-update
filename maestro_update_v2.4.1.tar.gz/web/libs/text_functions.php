<?php
// Copyright (C) 2026 by AD Audio
//

// Clean user data from form submits
function clean($elem)
{
    if(!is_array($elem))
        $elem = htmlentities($elem,ENT_QUOTES,"UTF-8");
    else
        foreach ($elem as $key => $value)
            $elem[$key] = clean($value);
    return $elem;
} 

// Strip extra spaces within strings
function StripExtraSpace($s)
{
	$newstr ='';
	for($i = 0; $i < strlen($s); $i++)
	{
	  $newstr = $newstr . substr($s, $i, 1);
	  if(substr($s, $i, 1) == ' ')
	  while(substr($s, $i + 1, 1) == ' ')
	  $i++;
	}
return $newstr;
}

// Get a string from a file or return UKNOWN if there is a problem
function fget_contents() {
    $args = func_get_args();
    $contents = @call_user_func_array('file_get_contents', $args);
    if ($contents === false) {
        $contents ='UNKNOWN';
    }
        return trim($contents);
}

function randomHex(){
	$hex = str_pad(strtoupper(dechex(rand( 0,255))), 2, '0', STR_PAD_LEFT);
	return $hex;
}

function RandomMac(){
	$RandomMac ='52:51:50:'.randomHex().':'.randomHex().':'.randomHex();
	return $RandomMac;
}

function NotMac($address){
If(strlen($address) > 17) return 1;
If($address == '') return 1;
If (!eregi('^[0-9A-Z]+(\:[0-9A-Z]+)+(\:[0-9A-Z]+)+(\:[0-9A-Z]+)+(\:[0-9A-Z]+)+(\:[0-9A-Z]+)$',$address)) return 1;
$Array=explode(':',$address);
If(strlen($Array[0]) != 2) return 1;
If(strlen($Array[1]) != 2) return 1;
If(strlen($Array[2]) != 2) return 1;
If(strlen($Array[3]) != 2) return 1;
If(strlen($Array[4]) != 2) return 1;
If(strlen($Array[5]) != 2) return 1;
return 0;
}
?>
