<?php
$eth = trim(shell_exec('/usr/local/bin/get-maestro-mac.sh'));
$mac_raw = trim(shell_exec('/usr/local/bin/get-maestro-mac.sh'));
$status_info = shell_exec("sudo /usr/local/bin/check-license 2>/dev/null");

$msg = "";
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_POST['license_key'])) {
    $key = trim($_POST['license_key']);
    $res = trim(shell_exec("sudo /opt/maestro/license_validator.bin " . escapeshellarg($key)));
    
    if (strpos($res, "SUCCESS") !== false) {
        $msg = "<div style='background:#d4edda; color:#155724; padding:12px; border-radius:5px; margin-bottom:15px; font-weight:bold; text-align:center; border:1px solid #c3e6cb;'>✓ Kích hoạt bản quyền thành công! Thiết bị đã được mở khóa.</div>";
        $status_info = shell_exec("sudo /usr/local/bin/check-license 2>/dev/null");
    } elseif (strpos($res, "ALREADY_USED") !== false) {
        $msg = "<div style='background:#fff3cd; color:#856404; padding:12px; border-radius:5px; margin-bottom:15px; font-weight:bold; text-align:center; border:1px solid #ffeeba;'>⚠ Mã kích hoạt này đã được sử dụng trước đó!</div>";
    } else {
        $msg = "<div style='background:#f8d7da; color:#721c24; padding:12px; border-radius:5px; margin-bottom:15px; font-weight:bold; text-align:center; border:1px solid #f5c6cb;'>✕ Mã kích hoạt không hợp lệ cho thiết bị này!</div>";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Maestro - License Manager</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
    <style>
        body { background: #f8f9fa; font-family: 'Segoe UI', Arial, sans-serif; }
        .main-container { max-width: 850px; margin: 30px auto; background: #fff; border-radius: 8px; box-shadow: 0 4px 15px rgba(0,0,0,0.08); padding: 30px; }
        .header-logo { text-align: center; margin-bottom: 25px; }
        .nav-btns { display: flex; justify-content: center; gap: 8px; flex-wrap: wrap; margin-bottom: 25px; }
        .nav-btns a { border-radius: 6px; font-weight: 500; }
        .license-box { background: #f1f3f5; border-left: 4px solid #007bff; padding: 15px; border-radius: 4px; font-family: monospace; font-size: 14px; white-space: pre-wrap; margin-bottom: 25px; }
        .mac-badge { font-size: 16px; background: #e9ecef; padding: 4px 10px; border-radius: 4px; font-weight: bold; color: #d63384; }
    </style>
</head>
<body>

<div class="container main-container">
    <div class="header-logo">
        <h2 style="color: #0056b3; font-weight: bold;">MAESTRO AUDIOPHILE SYSTEM</h2>
        <p class="text-muted">License & System Activation Center</p>
    </div>

    <!-- Thanh Menu chuẩn của Maestro -->
$mac = trim(shell_exec('/usr/local/bin/get-maestro-mac.sh'));
        <a href="/lms_redirect.php" target="_blank" class="btn btn-outline-primary">🏠 Home</a>
        <a href="server_selection.php" class="btn btn-outline-primary">🎛 Server Selection</a>
        <a href="playergui.php" class="btn btn-outline-primary">⚙ HW Selection</a>
        <a href="storage.php" class="btn btn-outline-primary">💽 NAS Storage</a>
$mac = trim(shell_exec('/usr/local/bin/get-maestro-mac.sh'));
        <a href="license.php" class="btn btn-primary">🔑 License</a>
    </div>

    <hr>
    <?=$msg?>

    <div class="mb-4">
        <h4>Thông Tin Thiết Bị</h4>
        <p>Địa chỉ MAC phần cứng: <span class="mac-badge"><?=htmlspecialchars($mac_raw)?></span></p>
    </div>

    <div class="license-box"><?=htmlspecialchars($status_info)?></div>

    <div class="card p-4 border-0 shadow-sm" style="background: #ffffff; border: 1px solid #e0e0e0 !important; border-radius: 8px;">
        <h5 style="margin-bottom: 15px; color: #333;">Nhập Mã Kích Hoạt (License Key)</h5>
        <form method="POST">
            <div class="form-group mb-3">
                <input type="text" name="license_key" class="form-control form-control-lg" placeholder="VD: YEAR-20260823-A1B2C3D4E5F6" style="text-transform: uppercase; font-family: monospace; letter-spacing: 1px;" required>
            </div>
            <button type="submit" class="btn btn-success btn-lg w-100 font-weight-bold">Xác Nhận Kích Hoạt</button>
        </form>
    </div>
</div>

</body>
</html>
