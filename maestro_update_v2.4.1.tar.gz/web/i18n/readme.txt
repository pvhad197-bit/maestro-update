To create a new language create the proper i18n/<lang_code>/LC_MESSAGES directory structure.
Copy the VortexBox.pot file to i18n/<lang_code>/LC_MESSAGES/VortexBox.po
Translate your text strings from this file then create the .mo file:

msgfmt -v VortexBox.po -o VortexBox.mo
