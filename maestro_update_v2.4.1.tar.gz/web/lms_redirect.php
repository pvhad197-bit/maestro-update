<?php
$lan_ip = trim(shell_exec("ip -4 route get 1.1.1.1 2>/dev/null | awk '{print $7; exit}'"));
if (empty($lan_ip)) {
    $lan_ip = trim(shell_exec("hostname -I 2>/dev/null | awk '{print $1}'"));
}
if (empty($lan_ip) || !filter_var($lan_ip, FILTER_VALIDATE_IP)) {
    $lan_ip = $_SERVER['SERVER_ADDR'] ?? '127.0.0.1';
}
header("Location: http://" . $lan_ip . ":9000/");
exit;
?>