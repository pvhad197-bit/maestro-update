<?php
exec("systemctl is-active squeezeboxserver.service lyrionmusicserver.service logitechmediaserver.service 2>/dev/null | grep -q '^active$' && echo 'active'", $output_lms);
exec("systemctl is-active roonserver.service 2>/dev/null", $output_roon);

$lms_status = (isset($output_lms[0]) && trim($output_lms[0]) === 'active') ? '1' : '0';
$roon_status = (isset($output_roon[0]) && trim($output_roon[0]) === 'active') ? '1' : '0';
?>
