<?php
// Copyright (C) 2022-2026 by AD Audio - Maestro OS
require_once 'libs/setup.php';

$message = '';
$msg_type = 'info';

// Tự động nhận diện interface mạng Ethernet (ưu tiên eth0 hoặc en*)
$detected_eth = trim(shell_exec("ip -o link show 2>/dev/null | awk -F': ' '{print \$2}' | grep -E '^(eth|en)' | head -n1"));
$eth_iface = !empty($detected_eth) ? $detected_eth : 'eth0';

// Tìm tên kết nối NetworkManager tương ứng với card mạng
$eth_con = trim(shell_exec("sudo /usr/bin/nmcli -t -f DEVICE,NAME con show --active 2>/dev/null | grep '^" . escapeshellarg($eth_iface) . ":' | cut -d: -f2- | head -n1"));
if (empty($eth_con)) {
    $eth_con = trim(shell_exec("sudo /usr/bin/nmcli -t -f NAME,TYPE con show 2>/dev/null | grep ':802-3-ethernet' | cut -d: -f1 | head -n1"));
}
if (empty($eth_con)) {
    $eth_con = 'Wired connection 1';
}

$action = isset($_REQUEST['action']) ? $_REQUEST['action'] : 'default';

// Hàm chuyển đổi Subnet Mask sang CIDR Prefix (VD: 255.255.255.0 -> 24)
function netmask_to_cidr($mask_str) {
    $mask_str = trim((string)$mask_str);
    if (is_numeric($mask_str) && (int)$mask_str > 0 && (int)$mask_str <= 32) {
        return (int)$mask_str;
    }
    $long = ip2long($mask_str);
    if ($long !== false) {
        $base = decbin($long);
        return substr_count($base, '1');
    }
    return 24;
}

// Hàm chuyển đổi CIDR sang Subnet Mask (VD: 24 -> 255.255.255.0)
function cidr_to_netmask($cidr) {
    $cidr = (int)$cidr;
    if ($cidr <= 0 || $cidr > 32) $cidr = 24;
    $mask = ~((1 << (32 - $cidr)) - 1);
    return long2ip($mask);
}

// XỬ LÝ LƯU CẤU HÌNH IP
if ($action === 'set_ip') {
    $ip_mode = isset($_POST['ip_mode']) ? trim($_POST['ip_mode']) : 'dhcp';
    
    if ($ip_mode === 'dhcp') {
        // Chuyển sang IP Động (DHCP)
        shell_exec("sudo /usr/bin/nmcli connection modify " . escapeshellarg($eth_con) . " ipv4.method auto ipv4.addresses '' ipv4.gateway '' ipv4.dns '' 2>/dev/null");
        shell_exec("sudo /usr/bin/nmcli connection up " . escapeshellarg($eth_con) . " >/dev/null 2>&1 &");
        $message = "Switched to Dynamic IP (DHCP). The router will automatically assign an IP address.";
        $msg_type = 'success';
    } elseif ($ip_mode === 'static') {
        // Chuyển sang IP Tĩnh (Static IP)
        $static_ip = isset($_POST['static_ip']) ? trim($_POST['static_ip']) : '';
        $netmask_in = isset($_POST['netmask']) ? trim($_POST['netmask']) : '255.255.255.0';
        $gateway = isset($_POST['gateway']) ? trim($_POST['gateway']) : '';
        $dns = isset($_POST['dns']) ? trim($_POST['dns']) : '8.8.8.8, 1.1.1.1';
        
        if (filter_var($static_ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {
            $prefix = netmask_to_cidr($netmask_in);
            $dns_clean = preg_replace('/[\s,]+/', ' ', $dns);
            
            $cmd = "sudo /usr/bin/nmcli connection modify " . escapeshellarg($eth_con) . " ipv4.method manual ipv4.addresses " . escapeshellarg("{$static_ip}/{$prefix}");
            if (!empty($gateway) && filter_var($gateway, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {
                $cmd .= " ipv4.gateway " . escapeshellarg($gateway);
            }
            if (!empty($dns_clean)) {
                $cmd .= " ipv4.dns " . escapeshellarg($dns_clean);
            }
            $cmd .= " 2>&1";
            shell_exec($cmd);
            shell_exec("sudo /usr/bin/nmcli connection up " . escapeshellarg($eth_con) . " >/dev/null 2>&1 &");
            
            $message = "Static IP saved: {$static_ip}. Please access the web interface at: http://{$static_ip}/";
            $msg_type = 'success';
        } else {
            $message = "Invalid static IP address! Please check your network input.";
            $msg_type = 'error';
        }
    }
}

// THU THẬP THÔNG TIN MẠNG HIỆN TẠI
$lan_cidr_raw = trim(shell_exec("ip -4 -o addr show $eth_iface 2>/dev/null | awk '{print \$4}' | head -n1"));
$lan_ip = 'Not connected';
$lan_prefix = 24;
if (!empty($lan_cidr_raw) && strpos($lan_cidr_raw, '/') !== false) {
    list($lan_ip, $lan_prefix) = explode('/', $lan_cidr_raw, 2);
} elseif (!empty($lan_cidr_raw)) {
    $lan_ip = $lan_cidr_raw;
}

$lan_oper = trim(@file_get_contents("/sys/class/net/$eth_iface/operstate"));
$speed_raw = trim(@file_get_contents("/sys/class/net/$eth_iface/speed"));
$lan_mac = trim(@file_get_contents("/sys/class/net/$eth_iface/address"));

// Gateway
$lan_gw = trim(shell_exec("ip route show dev $eth_iface default 2>/dev/null | awk '{print \$3}' | head -n1"));
if (empty($lan_gw)) {
    $lan_gw = trim(shell_exec("ip route 2>/dev/null | grep '^default' | awk '{print \$3}' | head -n1"));
}

// DNS
$lan_dns = trim(shell_exec("grep -E '^nameserver' /etc/resolv.conf 2>/dev/null | awk '{print \$2}' | paste -sd, -"));
if (empty($lan_dns)) {
    $lan_dns = '8.8.8.8, 1.1.1.1';
}

// Kiểm tra chế độ IP hiện tại của NetworkManager (manual = static, auto = dhcp)
$nm_method = trim(shell_exec("sudo /usr/bin/nmcli -t -f ipv4.method con show " . escapeshellarg($eth_con) . " 2>/dev/null | cut -d: -f2"));
$current_mode = ($nm_method === 'manual') ? 'static' : 'dhcp';

$lan_info = array(
    'interface'  => $eth_iface,
    'link_state' => ($lan_oper === 'up') ? 'Active (Priority 1)' : 'Cable Unplugged',
    'speed'      => (is_numeric($speed_raw) && $speed_raw > 0) ? (($speed_raw >= 1000) ? ($speed_raw/1000) . " Gbps Full-Duplex" : $speed_raw . " Mbps Full-Duplex") : 'Link Down',
    'ip'         => $lan_ip,
    'netmask'    => cidr_to_netmask($lan_prefix),
    'prefix'     => $lan_prefix,
    'gateway'    => !empty($lan_gw) ? $lan_gw : '192.168.1.1',
    'dns'        => $lan_dns,
    'mac'        => !empty($lan_mac) ? strtoupper($lan_mac) : 'N/A',
    'mode'       => $current_mode,
    'status'     => ($lan_oper === 'up' && $lan_ip !== 'Not connected') ? 'Connected' : 'Disconnected'
);

$smarty->assign('lan_info', $lan_info);
$smarty->assign('message', $message);
$smarty->assign('msg_type', $msg_type);

$smarty->display('network.tpl');
?>
