<?php
if (file_exists('libs/setup.php')) {
    require_once('libs/setup.php');
} elseif (file_exists('setup.php')) {
    require_once('setup.php');
}

if (file_exists('libs/tzList.php')) { 
    require_once('libs/tzList.php'); 
}

$trigger_file = '/var/www/html/config/switch_trigger';
$status_json  = '/var/www/html/config/status.json';
$state_file   = '/var/www/html/config/active_server.cfg';
$install_flag = '/var/www/html/config/roon_install.status';
$action = isset($_GET['action']) ? $_GET['action'] : '';

if ($action == 'EnableRoon') {
    file_put_contents($trigger_file, 'roon');
    file_put_contents($state_file, 'roon');
    
    // Nếu chưa có thư mục RoonServer thì đánh dấu là đang cài đặt
    if (!is_dir('/opt/RoonServer')) {
        file_put_contents($status_json, json_encode(['roon' => 'Installing', 'lyrion' => 'No']));
        touch($install_flag);
    } else {
        file_put_contents($status_json, json_encode(['roon' => 'Yes', 'lyrion' => 'No']));
    }
    chmod($status_json, 0666);
    
    exec('sudo /usr/local/bin/maestro_audio_ctl roon > /dev/null 2>&1 &');
    sleep(1);
    header("Location: server.php");
    exit;
} elseif ($action == 'EnableLyrion') {
    @unlink($install_flag);
    file_put_contents($trigger_file, 'lyrion');
    file_put_contents($state_file, 'lyrion');
    file_put_contents($status_json, json_encode(['roon' => 'No', 'lyrion' => 'Yes']));
    chmod($status_json, 0666);
    
    exec('sudo /usr/local/bin/maestro_audio_ctl lms > /dev/null 2>&1 &');
    sleep(1);
    header("Location: server.php");
    exit;
} elseif ($action == 'ShutDown') {
    exec('sudo /usr/bin/systemctl poweroff > /dev/null 2>&1 &');
} elseif ($action == 'Restart') {
    exec('sudo /usr/bin/systemctl reboot > /dev/null 2>&1 &');
}

$roon_val = 'No';
$lyrion_val = 'Yes';

if (file_exists($status_json)) {
    $data = json_decode(file_get_contents($status_json), true);
    if (is_array($data)) {
        $roon_val = $data['roon'] ?? 'No';
        $lyrion_val = $data['lyrion'] ?? 'Yes';
    }
}

if (file_exists($install_flag)) {
    $roon_val = 'Installing';
}

if (isset($smarty)) {
    $smarty->assign('roon_running', $roon_val);
    $smarty->assign('lyrion_running', $lyrion_val);
    $smarty->assign('is_installing', ($roon_val === 'Installing'));

    if (file_exists("iconlist.php")) {
        include_once("iconlist.php");
    }

    $smarty->display('server.tpl');
}
?>
