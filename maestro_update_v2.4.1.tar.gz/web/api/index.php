<?php
// Copyright (C) 2008 - 2011 vortexbox.org
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//

define("APIVERSION", "1.0");

require 'RestServer.php';
require 'api_functions.php';

class Welcome
{
    /**
     * Returns a JSON string object to the browser when hitting the root of the domain
     *
     * @url GET /api
     */
    public function welcome()
    {
        return "VortexBox API ver: ".APIVERSION;
    }
}

class DiskSpace
{
    /**
     * Returns a JSON list of drive info
     *
     * @url GET /api/DiskSpace
     */
    public function diskspace()
    { 
		$diskinfo = array();
		$df = explode(" ",StripExtraSpace(exec("df -h --total /storage | grep total")));
		echo $df;
		$diskinfo['StorageSize'] = $df[1];
		$diskinfo['StorageUsed'] = $df[2];
		$diskinfo['StorageAvail'] = $df[3];
		$diskinfo['StoragePercent'] = $df[4];
        return json_encode( $diskinfo, JSON_NUMERIC_CHECK );
    }
}

spl_autoload_register(); // don't load our classes unless we use them

//$mode = 'production';
$mode = 'debug';

$server = new RestServer($mode);
$server->refreshCache(); // uncomment momentarily to clear the cache if classes change in production mode

$server->addClass('Welcome');
$server->addClass('DiskSpace');

$server->handle();

?>
