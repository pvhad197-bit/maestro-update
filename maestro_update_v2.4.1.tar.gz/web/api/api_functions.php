<?php
function StripExtraSpace($s)
{
	for($i = 0; $i < strlen($s); $i++)
	{
	  $newstr = $newstr . substr($s, $i, 1);
	  if(substr($s, $i, 1) == ' ')
	  while(substr($s, $i + 1, 1) == ' ')
	  $i++;
	}
return $newstr;
}
?>
