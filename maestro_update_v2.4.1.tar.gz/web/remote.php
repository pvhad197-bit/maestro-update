<?php
session_start();

// MÃ BĂM BCRYPT MẬT KHẨU (KHÔNG THỂ DỊCH NGƯỢC TỪ USB CỨU HỘ)
define('MASTER_HASH', '$2y$12$jQNhE6Xq1JbsxI8m3U/5bOkCRRxP.hNc4aElUKBvfqIFcfCMcc1bS');

// Lock session
if (isset($_GET['lock'])) {
    unset($_SESSION['maestro_auth']);
    header("Location: remote.php");
    exit;
}

// Authentication with Bcrypt hash verification
$error = "";
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['pin'])) {
    if (password_verify($_POST['pin'], MASTER_HASH)) {
        $_SESSION['maestro_auth'] = true;
        header("Location: remote.php");
        exit;
    } else {
        $error = "Invalid master password. Access denied.";
    }
}

$is_auth = !empty($_SESSION['maestro_auth']);

// Action handling (Enable / Disable)
if ($is_auth && $_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $act = ($_POST['action'] === 'enable') ? 'enable' : (($_POST['action'] === 'disable') ? 'disable' : '');
    if ($act !== '') {
        shell_exec("sudo /usr/local/bin/maestro-ssh-ctl " . escapeshellarg($act));
        usleep(400000); // Wait 0.4s for daemon state update
    }
    header("Location: remote.php");
    exit;
}

// Direct kernel socket check (Zero sudo dependency, 100% accurate)
$fp = @fsockopen('127.0.0.1', 22, $errno, $errstr, 0.2);
if ($fp) {
    $status = 'ACTIVE';
    fclose($fp);
} else {
    $status = 'INACTIVE';
}

$ip = $_SERVER['SERVER_ADDR'] ?? '192.168.1.7';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Maestro OS - SSH Settings</title>
    <style>
        * { box-sizing: border-box; }
        body { background: #121824; color: #fff; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0; }
        .card { background: #1b2436; padding: 32px; border-radius: 12px; box-shadow: 0 10px 30px rgba(0,0,0,0.5); width: 380px; text-align: center; }
        h2 { font-size: 1.25rem; margin: 0 0 22px 0; color: #64b5f6; font-weight: 600; letter-spacing: 0.5px; }
        .info-row { display: flex; justify-content: space-between; align-items: center; padding: 12px 0; border-bottom: 1px solid #28354d; font-size: 0.95rem; }
        .info-label { color: #cfd8dc; }
        .status-badge { font-weight: bold; padding: 4px 12px; border-radius: 4px; font-size: 0.8rem; letter-spacing: 0.5px; }
        .badge-active { background: #1b5e20; color: #81c784; }
        .badge-inactive { background: #b71c1c; color: #ef9a9a; }
        .btn { width: 100%; padding: 13px; border: none; border-radius: 6px; font-weight: bold; cursor: pointer; font-size: 0.95rem; margin-top: 24px; transition: opacity 0.2s; letter-spacing: 0.5px; }
        .btn:hover { opacity: 0.9; }
        .btn-disable { background: #e53935; color: white; }
        .btn-enable { background: #2e7d32; color: white; }
        .pin-input { width: 100%; padding: 12px; border-radius: 6px; border: 1px solid #37474f; background: #121824; color: #fff; text-align: center; font-size: 1rem; margin-bottom: 12px; outline: none; }
        .pin-input:focus { border-color: #64b5f6; }
        .subtext { margin-top: 18px; font-size: 0.78rem; color: #90a4ae; line-height: 1.45; text-align: center; }
        .lock-link { display: inline-block; margin-top: 16px; color: #78909c; text-decoration: none; font-size: 0.82rem; transition: color 0.2s; }
        .lock-link:hover { color: #cfd8dc; }
        .error { color: #ef5350; font-size: 0.85rem; margin-bottom: 14px; }
    </style>
</head>
<body>
<div class="card">
    <?php if (!$is_auth): ?>
        <h2>Security Verification</h2>
        <?php if ($error): ?><div class="error"><?= $error ?></div><?php endif; ?>
        <form method="POST">
            <input type="password" name="pin" class="pin-input" placeholder="Enter Master Password" autofocus required>
            <button type="submit" class="btn btn-enable" style="margin-top: 6px;">UNLOCK ACCESS</button>
        </form>
    <?php else: ?>
        <h2>SSH Service Management</h2>
        <div class="info-row"><span class="info-label">Host IP:</span><span><?= $ip ?></span></div>
        <div class="info-row"><span class="info-label">Port:</span><span>22</span></div>
        <div class="info-row">
            <span class="info-label">Status:</span>
            <span class="status-badge <?= $status === 'ACTIVE' ? 'badge-active' : 'badge-inactive' ?>">● <?= $status ?></span>
        </div>
        
        <form method="POST" action="remote.php">
            <?php if ($status === 'ACTIVE'): ?>
                <input type="hidden" name="action" value="disable">
                <button type="submit" class="btn btn-disable">DISABLE SSH</button>
            <?php else: ?>
                <input type="hidden" name="action" value="enable">
                <button type="submit" class="btn btn-enable">ENABLE SSH</button>
            <?php endif; ?>
        </form>
        
        <div class="subtext">
            Disabling SSH conserves background system resources and prevents unauthorized network port scanning.
        </div>
        
        <a href="remote.php?lock=1" class="lock-link">🔒 Lock Session</a>
    <?php endif; ?>
</div>
</body>
</html>
