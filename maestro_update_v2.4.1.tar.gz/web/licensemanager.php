<?php
// Copyright (C) 2026 by AD Audio
//
require_once ('libs/setup.php');

$_action = isset($_REQUEST['action']) ? $_REQUEST['action'] : 'default';

exec("sudo /opt/maestro/doaction.sh GetMKVconfig >/dev/null 2>&1");

$config = parse_ini_file("/tmp/settings.conf");

switch($_action) {
    case 'submit':
		if (isset($_REQUEST['MAKEMKVLICENSE']) & !$_REQUEST['MAKEMKVLICENSE'] =="") { 
			$config['app_Key'] = $_REQUEST['MAKEMKVLICENSE']; 
		} else {
			unset($config["app_Key"]);
		}

		if($file = fopen("/tmp/settings.conf", "w"));
		foreach ($config as $key => $value)
		{
			fwrite($file, $key ." = ".'"'.$value.'"'."\n");
		}
		fclose($file);
		exec("sudo /opt/maestro/doaction.sh PutMKVconfig >/dev/null 2>&1");
	
		break;

	default:
}

if (isset($config["app_Key"])) {  
	$MakemkvLicense = $config["app_Key"];
} else {
	$MakemkvLicense = "";
}

$smarty->assign('MAKEMKVLICENSE', $MakemkvLicense);
$smarty->display('licensemanager.tpl');

?>
