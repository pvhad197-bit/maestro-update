{include file="header.tpl"}

<div class="xsnazzy">
<b class="xtop"><b class="xb1"></b><b class="xb2 color_a"></b><b class="xb3 color_a"></b><b class="xb4 color_a"></b></b>
<div class="xboxcontent">

<div style="max-width: 650px; margin: 0 auto;">
    <h1 class="color_a" style="margin-top: 10px; margin-bottom: 20px; text-align: left;">{t}Server Selection{/t}</h1>

    <div style="margin-bottom: 20px;">
        <a href="server.php?action=ShutDown" onclick="return confirm('Are you sure you want to ShutDown?');" style="display: inline-block; padding: 7px 18px; font-weight: bold; text-decoration: none; color: #333; background: #eee; border: 1px solid #999; border-radius: 3px; margin-right: 10px;">ShutDown</a>
        <a href="server.php?action=Restart" onclick="return confirm('Are you sure you want to Restart?');" style="display: inline-block; padding: 7px 18px; font-weight: bold; text-decoration: none; color: #333; background: #eee; border: 1px solid #999; border-radius: 3px;">Restart</a>
    </div>

    <hr style="border: 0; border-top: 1px solid #ccc; margin: 15px 0;">

    <h3 style="margin-bottom: 12px;">Music Server</h3>
    <p style="font-size: 15px; margin: 6px 0;">
        Roon running: 
        {if $roon_running eq 'Yes'}
            <b style="color: green;">Yes</b>
        {elseif $roon_running eq 'Installing'}
            <b style="color: #d97706;">Installing...</b>
        {else}
            <b style="color: red;">No</b>
        {/if}
    </p>
    <p style="font-size: 15px; margin: 6px 0;">
        Lyrion running: 
        {if $lyrion_running eq 'Yes'}
            <b style="color: green;">Yes</b>
        {else}
            <b style="color: red;">No</b>
        {/if}
    </p>

    <div style="margin-top: 20px;">
        <!-- NÚT CHỌN ROON -->
        <div style="margin-bottom: 12px;">
            {if $is_installing}
                <a href="javascript:void(0);" style="display: inline-block; width: 220px; text-align: center; padding: 8px 0; font-weight: bold; text-decoration: none; color: #b45309; background: #fef3c7; border: 1px solid #f59e0b; border-radius: 4px; cursor: wait; pointer-events: none;">Installing Roon... (Please wait)</a>
            {elseif $roon_running eq 'Yes'}
                <a href="javascript:void(0);" style="display: inline-block; width: 140px; text-align: center; padding: 8px 0; font-weight: bold; text-decoration: none; color: #999; background: #e9ecef; border: 1px solid #ccc; border-radius: 4px; cursor: not-allowed; pointer-events: none; opacity: 0.5;">Use Roon</a>
            {else}
                <a href="server.php?action=EnableRoon" style="display: inline-block; width: 140px; text-align: center; padding: 8px 0; font-weight: bold; text-decoration: none; color: #000; background: #f4f4f4; border: 1px solid #888; border-radius: 4px;">Use Roon</a>
            {/if}
        </div>

        <!-- NÚT CHỌN LYRION -->
        <div>
            {if $is_installing or $lyrion_running eq 'Yes'}
                <a href="javascript:void(0);" style="display: inline-block; width: 140px; text-align: center; padding: 8px 0; font-weight: bold; text-decoration: none; color: #999; background: #e9ecef; border: 1px solid #ccc; border-radius: 4px; cursor: not-allowed; pointer-events: none; opacity: 0.5;">Use Lyrion</a>
            {else}
                <a href="server.php?action=EnableLyrion" style="display: inline-block; width: 140px; text-align: center; padding: 8px 0; font-weight: bold; text-decoration: none; color: #000; background: #f4f4f4; border: 1px solid #888; border-radius: 4px;">Use Lyrion</a>
            {/if}
        </div>

        {if $is_installing}
            <div style="margin-top: 15px; padding: 10px 15px; background: #f0f9ff; border-left: 4px solid #0284c7; color: #0369a1; font-size: 13px; line-height: 1.4; max-width: 480px;">
                <strong>Downloading official Roon Server...</strong><br>
                The package is downloading directly from Roon Labs (about 1 minute). The page will auto-refresh when complete.
            </div>
            <script>
                setTimeout(function(){ window.location.reload(); }, 5000);
            </script>
        {/if}
    </div>
</div>

<br>
</div>
<b class="xbottom"><b class="xb4"></b><b class="xb3"></b><b class="xb2"></b><b class="xb1"></b></b>
</div>

{include file="footer.tpl"}
