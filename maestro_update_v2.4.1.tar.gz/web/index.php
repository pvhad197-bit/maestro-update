<?php
// Copyright (C) 2025 by AD Audio
//
require_once 'libs/setup.php';

$storageinfo = explode(" ",StripExtraSpace(exec("df -h --total /storage | grep total")));
$smarty->assign('STORAGESIZE', $storageinfo[1]);
$smarty->assign('STORAGEUSED', $storageinfo[2]);
$smarty->assign('STORAGEAVAIL', $storageinfo[3]);
$smarty->assign('STORAGEPERCENT', $storageinfo[4]);

$smarty->assign('SYSNAME', getSysVar('Hostname'));
$smarty->assign('FEDORAVER', 'Maestro OS - v1.0 (Audiophile Edition)');
$smarty->assign('IPADDRESS', getSysVar('IPaddress'));

// --- MAESTRO OTA UPDATE HANDLER ---
$ota_log = '';
if (isset($_POST['action_do_update'])) {
    $ota_log = shell_exec('sudo /usr/local/bin/maestro-update 2>&1');
}
$smarty->assign('ota_log', $ota_log);
$smarty->assign('MACADDRESS', getSysVar('MacAddress'));
$smarty->assign('NIC', (isset($nic) && strpos($nic, 'wl') === 0 ? 'wlan0' : 'eth0'));











// --- XỬ LÝ BẢN QUYỀN MAESTRO ---
$license_msg = "";
if ($_SERVER["REQUEST_METHOD"] === "POST" && !empty($_POST["license_key"])) {
    $key = trim($_POST["license_key"]);
    $res = trim(shell_exec("/usr/local/bin/license_runner " . escapeshellarg($key) . " 2>&1"));
    if (strpos($res, "SUCCESS") !== false) {
        shell_exec("sudo systemctl enable --now maestro-player roonserver 2>&1");
        shell_exec("sudo systemctl reset-failed maestro-player roonserver 2>/dev/null; sudo systemctl restart maestro-player roonserver 2>/dev/null &");
        $license_msg = "<div style=\"color:#28a745;font-weight:bold;margin:10px 0;\">✓ License activated successfully!</div>";
    } elseif (strpos($res, "ALREADY_USED") !== false) {
        $license_msg = "<div style=\"color:#ffc107;font-weight:bold;margin:10px 0;\">⚠ This license key has already been used!</div>";
    } else {
        $license_msg = "<div style=\"color:#dc3545;font-weight:bold;margin:10px 0;\">✕ Invalid license key!</div>";
    }
}

// Luôn đọc trạng thái SAU KHI kích hoạt xong
$status_info = trim(shell_exec("/usr/local/bin/license_runner 2>&1"));

if (isset($smarty)) {
    $smarty->assign("LICENSE_MSG", $license_msg);
    $smarty->assign("LICENSE_STATUS", $status_info);
}
// --------------------------------


// === MAESTRO DYNAMIC NETWORK (LAN > WIFI) ===
$net_info = json_decode(shell_exec('/usr/local/bin/get-maestro-network.sh 2>/dev/null'), true);
$nic = $net_info['nic'] ?? 'eth0';
$ip  = $net_info['ip'] ?? 'Not Connected';
$mac = $net_info['mac'] ?? trim(shell_exec('/usr/local/bin/get-maestro-mac.sh 2>/dev/null'));


if (isset($drives_list)) { $smarty->assign('DRIVES', $drives_list); }

$smarty->assign('NIC', (isset($nic) && strpos($nic, 'wl') === 0 ? 'wlan0' : 'eth0'));

// === MAESTRO SYSTEM NAME & HOSTNAME HANDLER ===
if (isset($_POST['action']) && $_POST['action'] === 'change_sysname') {
    $raw_name = $_POST['new_sysname'] ?? $_POST['sysname'] ?? '';
    $raw_name = trim($raw_name);
    
    if (!empty($raw_name)) {
        // Chỉ giữ chữ thường, số và dấu gạch ngang
        $clean_name = strtolower(preg_replace('/[^a-zA-Z0-9\-]/', '', $raw_name));
        
        if (!empty($clean_name) && $clean_name !== 'localhost') {
            // 1. Cập nhật qua kịch bản mDNS và /etc/hosts
            shell_exec("sudo /usr/local/bin/maestro-update-hostname.sh " . escapeshellarg($clean_name) . " >/dev/null 2>&1");
            shell_exec("sudo hostnamectl set-hostname " . escapeshellarg($clean_name) . " 2>/dev/null");
            
            // 2. Chuyển hướng kèm tham số để kích hoạt banner thông báo thành công trong index.tpl
            header("Location: index.php?updated_sysname=" . urlencode($clean_name));
            exit;
        }
    }
    header("Location: index.php");
    exit;
}

// Đọc hostname hiện tại đưa vào template
$current_sysname = trim(shell_exec('hostname 2>/dev/null'));
if (empty($current_sysname) || $current_sysname === 'localhost') {
    $current_sysname = 'maestro';
}
if (isset($smarty)) {
    $smarty->assign('SYSNAME', $current_sysname);
    $smarty->assign('sysname', $current_sysname);
}


$net_info = json_decode(shell_exec('/usr/local/bin/get-maestro-network.sh 2>/dev/null'), true);
if (isset($smarty) && is_array($net_info)) {
    $smarty->assign('NIC', $net_info['nic'] ?? 'wlan0');
    $smarty->assign('LAN_NIC', $net_info['nic'] ?? 'wlan0');
    $smarty->assign('IPADDRESS', $net_info['ip'] ?? 'Not Connected');
}


$os_version = file_exists("/etc/maestro_version") ? trim(file_get_contents("/etc/maestro_version")) : "2.4.1";
$smarty->assign('os_version', $os_version);
$smarty->display('index.tpl');
pageLoadTest();
?>
