<?php
if (isset($_GET['val'])) {
    $val = trim($_GET['val']);
    // Cho phép cả số thập phân
    if (preg_match('/^[0-9]+(\.[0-9]+)?$/', $val) || $val === 'bypass') {
        file_put_contents('/etc/maestro_pitch_mode', $val);
        exec('sudo /usr/local/bin/maestro_pitch_ctl ' . escapeshellarg($val) . ' > /dev/null 2>&1 &');
        echo "OK: " . $val;
    }
}
?>
