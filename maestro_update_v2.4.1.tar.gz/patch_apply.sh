#!/bin/bash
set -e
echo "================================================="
echo "   TIẾN TRÌNH CẬP NHẬT MAESTRO OS LÊN v2.4.1     "
echo "================================================="

CURRENT_DIR=$(dirname "$(readlink -f "$0")")

echo "[1/6] Áp dụng khóa CPU Performance..."
cp -f "$CURRENT_DIR/files/maestro-cpu-performance.service" /etc/systemd/system/
for g in /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor; do
    [ -f "$g" ] && echo performance > "$g" 2>/dev/null || true
done
systemctl daemon-reload
systemctl enable maestro-cpu-performance.service

echo "[2/6] Loại bỏ triệt để C-3PO khỏi LMS..."
find /var/lib/squeezeboxserver/cache/InstalledPlugins/Plugins /usr/share/squeezeboxserver/Plugins -type d -name "*C3PO*" 2>/dev/null | while read p; do
    rm -rf "$p"
    echo "  -> Đã gỡ plugin: $p"
done
# Xóa cấu hình chuyển đổi can thiệp của C3PO nếu còn sót
rm -f /var/lib/squeezeboxserver/prefs/plugin/c3po.prefs 2>/dev/null || true

echo "[3/6] Cài đặt YouTube Mock API không giới hạn..."
cp -f "$CURRENT_DIR/files/maestro-yt-mock.py" /usr/local/bin/
chmod +x /usr/local/bin/maestro-yt-mock.py
cp -f "$CURRENT_DIR/files/maestro-yt-mock.service" /etc/systemd/system/
systemctl daemon-reload
systemctl enable --now maestro-yt-mock.service

# Chuyển hướng plugin YouTube của LMS sang cổng 8088
python3 - << 'PYEOF'
import glob, os
for sdir in ["/var/lib/squeezeboxserver", "/usr/share/squeezeboxserver"]:
    for fpath in glob.glob(f"{sdir}/**/YouTube/**/*.pm", recursive=True):
        try:
            with open(fpath, "r", encoding="utf-8", errors="ignore") as f:
                code = f.read()
            if "https://www.googleapis.com" in code:
                if not os.path.exists(fpath + ".orig"):
                    with open(fpath + ".orig", "w", encoding="utf-8") as bf:
                        bf.write(code)
                new_code = code.replace("https://www.googleapis.com", "http://127.0.0.1:8088")
                with open(fpath, "w", encoding="utf-8") as f:
                    f.write(new_code)
                print(f"  -> Đã patch API endpoint: {fpath}")
        except Exception:
            pass
PYEOF

echo "[4/6] Cấu hình Squeezelite Buffer chống giật đầu bài..."
for svc in "/etc/systemd/system/squeezelite-432evo.service" "/lib/systemd/system/squeezelite.service"; do
    if [ -f "$svc" ]; then
        sed -i -E 's/-b [0-9]+:[0-9]+/ -b 40000:100000 /g' "$svc"
    fi
done

echo "[5/6] Ẩn SSH Management thành remote.php..."
cd /var/www/html 2>/dev/null || true
if [ -f "ssh.php" ]; then
    mv -f ssh.php remote.php
    rm -f ssh.php
fi
find . -type f -name "ssh.tpl" 2>/dev/null | while read tpl; do
    mv -f "$tpl" "$(dirname "$tpl")/remote.tpl"
    rm -f "$tpl"
done
# Gỡ liên kết khỏi menu
python3 - << 'PYEOF'
import glob, re
for f in glob.glob("/var/www/html/**/*.*", recursive=True):
    if "templates_c" in f or "remote.php" in f or "remote.tpl" in f:
        continue
    if f.endswith((".php", ".tpl", ".html")):
        try:
            with open(f, "r", encoding="utf-8", errors="ignore") as file:
                content = file.read()
            new_content = re.sub(r'<li[^>]*>\s*<a[^>]*href=[\'"][^\'"]*(ssh|remote)\.php[\'"][^>]*>.*?</a>\s*</li>', '', content, flags=re.DOTALL | re.IGNORECASE)
            new_content = re.sub(r'<a[^>]*href=[\'"][^\'"]*(ssh|remote)\.php[\'"][^>]*>.*?</a>', '', new_content, flags=re.DOTALL | re.IGNORECASE)
            if new_content != content:
                with open(f, "w", encoding="utf-8") as file:
                    file.write(new_content)
        except Exception:
            pass
PYEOF
rm -rf /var/www/html/templates_c/*

echo "[6/6] Cập nhật Version System và khởi động lại dịch vụ..."
# Cập nhật số phiên bản nếu có file định danh
for vfile in "/etc/maestro-release" "/etc/maestro-version" "/var/www/html/version.txt"; do
    [ -f "$vfile" ] && echo "2.4.1" > "$vfile"
done

systemctl daemon-reload
systemctl restart maestro-yt-mock.service 2>/dev/null || true
systemctl restart squeezelite-432evo 2>/dev/null || systemctl restart squeezelite 2>/dev/null || true
systemctl restart logitechmediaserver 2>/dev/null || systemctl restart lms 2>/dev/null || true

echo "================================================="
echo "   CẬP NHẬT MAESTRO OS v2.4.1 THÀNH CÔNG!        "
echo "================================================="
