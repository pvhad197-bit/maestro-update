#!/bin/bash
set -e
DIR=$(dirname "$(readlink -f "$0")")

# Áp dụng CPU Performance
cp -f "$DIR/files/maestro-cpu-performance.service" /etc/systemd/system/
for g in /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor; do [ -f "$g" ] && echo performance > "$g" 2>/dev/null || true; done
systemctl daemon-reload && systemctl enable maestro-cpu-performance.service

# Xóa C-3PO
find /var/lib/squeezeboxserver/cache/InstalledPlugins/Plugins /usr/share/squeezeboxserver/Plugins -type d -name "*C3PO*" 2>/dev/null | xargs rm -rf 2>/dev/null || true
rm -f /var/lib/squeezeboxserver/prefs/plugin/c3po.prefs 2>/dev/null || true

# Cài Mock Engine
cp -f "$DIR/files/maestro-yt-mock.py" /usr/local/bin/
chmod +x /usr/local/bin/maestro-yt-mock.py
cp -f "$DIR/files/maestro-yt-mock.service" /etc/systemd/system/
systemctl daemon-reload && systemctl enable --now maestro-yt-mock.service

# Sửa endpoint YouTube LMS
python3 - << 'PYEOF'
import glob, os
for sdir in ["/var/lib/squeezeboxserver", "/usr/share/squeezeboxserver"]:
    for fpath in glob.glob(f"{sdir}/**/YouTube/**/*.pm", recursive=True):
        try:
            with open(fpath, "r", encoding="utf-8", errors="ignore") as f: code = f.read()
            if "https://www.googleapis.com" in code:
                if not os.path.exists(fpath + ".orig"):
                    with open(fpath + ".orig", "w", encoding="utf-8") as bf: bf.write(code)
                with open(fpath, "w", encoding="utf-8") as f: f.write(code.replace("https://www.googleapis.com", "http://127.0.0.1:8088"))
        except Exception: pass
PYEOF

# Buffer Squeezelite
for svc in "/etc/systemd/system/squeezelite-432evo.service" "/lib/systemd/system/squeezelite.service"; do
    [ -f "$svc" ] && sed -i -E 's/-b [0-9]+:[0-9]+/ -b 40000:100000 /g' "$svc"
done

# Ẩn trang SSH sang remote.php
cd /var/www/html 2>/dev/null || true
[ -f "ssh.php" ] && mv -f ssh.php remote.php && rm -f ssh.php
find . -type f -name "ssh.tpl" 2>/dev/null | while read tpl; do mv -f "$tpl" "$(dirname "$tpl")/remote.tpl" && rm -f "$tpl"; done
python3 - << 'PYEOF'
import glob, re
for f in glob.glob("/var/www/html/**/*.*", recursive=True):
    if any(x in f for x in ["templates_c", "remote.php", "remote.tpl"]): continue
    if f.endswith((".php", ".tpl", ".html")):
        try:
            with open(f, "r", encoding="utf-8", errors="ignore") as file: content = file.read()
            new_c = re.sub(r'<li[^>]*>\s*<a[^>]*href=[\'"][^\'"]*(ssh|remote)\.php[\'"][^>]*>.*?</a>\s*</li>', '', content, flags=re.DOTALL | re.IGNORECASE)
            new_c = re.sub(r'<a[^>]*href=[\'"][^\'"]*(ssh|remote)\.php[\'"][^>]*>.*?</a>', '', new_c, flags=re.DOTALL | re.IGNORECASE)
            if new_c != content:
                with open(f, "w", encoding="utf-8") as file: file.write(new_c)
        except Exception: pass
PYEOF
rm -rf /var/www/html/templates_c/*

# Cập nhật số phiên bản
for vfile in "/etc/maestro-release" "/etc/maestro-version" "/var/www/html/version.txt"; do
    [ -f "$vfile" ] && echo "2.4.1" > "$vfile"
done

# Khởi động lại dịch vụ
systemctl restart squeezelite-432evo 2>/dev/null || systemctl restart squeezelite 2>/dev/null || true
systemctl restart logitechmediaserver 2>/dev/null || systemctl restart lms 2>/dev/null || true
