#!/usr/bin/env python3
import json
import subprocess
import urllib.parse
from http.server import HTTPServer, BaseHTTPRequestHandler

class YouTubeMockHandler(BaseHTTPRequestHandler):
    def log_message(self, format, *args):
        return

    def do_GET(self):
        parsed = urllib.parse.urlparse(self.path)
        params = urllib.parse.parse_qs(parsed.query)

        if "/youtube/v3/search" in parsed.path:
            query = params.get('q', [''])[0]
            max_results = int(params.get('maxResults', ['25'])[0])
            max_results = min(max_results, 50)

            items = []
            if query:
                try:
                    cmd = [
                        "yt-dlp",
                        "--dump-json",
                        "--flat-playlist",
                        "--no-warnings",
                        f"ytsearch{max_results}:{query}"
                    ]
                    res = subprocess.run(cmd, capture_output=True, text=True, timeout=12)
                    for line in res.stdout.strip().split('\n'):
                        if not line:
                            continue
                        entry = json.loads(line)
                        vid = entry.get('id', '')
                        if not vid:
                            continue
                        title = entry.get('title', '')
                        uploader = entry.get('uploader') or entry.get('channel', '')
                        thumb = entry.get('thumbnail') or f"https://i.ytimg.com/vi/{vid}/hqdefault.jpg"

                        items.append({
                            "kind": "youtube#searchResult",
                            "id": {"kind": "youtube#video", "videoId": vid},
                            "snippet": {
                                "title": title,
                                "description": entry.get('description', '') or '',
                                "thumbnails": {
                                    "default": {"url": thumb},
                                    "medium": {"url": thumb},
                                    "high": {"url": thumb}
                                },
                                "channelTitle": uploader,
                                "liveBroadcastContent": "none"
                            }
                        })
                except Exception:
                    pass

            resp_bytes = json.dumps({
                "kind": "youtube#searchListResponse",
                "pageInfo": {"totalResults": len(items), "resultsPerPage": max_results},
                "items": items
            }).encode('utf-8')

            self.send_response(200)
            self.send_header('Content-Type', 'application/json; charset=utf-8')
            self.send_header('Content-Length', str(len(resp_bytes)))
            self.send_header('Connection', 'close')
            self.end_headers()
            self.wfile.write(resp_bytes)
            return

        elif "/youtube/v3/videos" in parsed.path:
            ids = params.get('id', [''])[0].split(',')
            items = []
            for vid in ids:
                if vid:
                    items.append({
                        "kind": "youtube#video",
                        "id": vid,
                        "contentDetails": {"duration": "PT4M00S"}
                    })
            resp_bytes = json.dumps({
                "kind": "youtube#videoListResponse",
                "pageInfo": {"totalResults": len(items)},
                "items": items
            }).encode('utf-8')

            self.send_response(200)
            self.send_header('Content-Type', 'application/json; charset=utf-8')
            self.send_header('Content-Length', str(len(resp_bytes)))
            self.send_header('Connection', 'close')
            self.end_headers()
            self.wfile.write(resp_bytes)
            return

        resp_bytes = b'{"items": []}'
        self.send_response(200)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Content-Length', str(len(resp_bytes)))
        self.send_header('Connection', 'close')
        self.end_headers()
        self.wfile.write(resp_bytes)

if __name__ == '__main__':
    server = HTTPServer(('127.0.0.1', 8088), YouTubeMockHandler)
    server.serve_forever()
