{include file="header.tpl"}

<style>
    /* Phóng to nút menu */
    .btn, a.btn, .nav-link, a[href*="hw.php"], a[href*="server.php"], a[href*="nas.php"], a[href*="index.php"] {
        font-size: 15px !important;
        font-weight: 600 !important;
        padding: 6px 16px !important;
    }

    /* Căn giữa trang và chống tràn khung */
    .hw-wrapper {
        width: 96% !important;
        max-width: 1180px !important;
        margin: 25px auto 40px auto !important;
        padding: 0 !important;
        box-sizing: border-box !important;
    }

    .hw-box {
        background: #ffffff;
        border: 1px solid #dcdcdc;
        border-radius: 8px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.05);
        padding: 25px 25px;
        margin-bottom: 25px;
        box-sizing: border-box !important;
        width: 100% !important;
    }

    .hw-title {
        text-align: center;
        font-size: 22px;
        font-weight: 700;
        color: #2b3a4a;
        margin-top: 0;
        margin-bottom: 25px;
    }

    /* Khóa bảng cố định 100% chiều ngang */
    .hw-table {
        width: 100% !important;
        table-layout: fixed !important;
        border-collapse: collapse !important;
        margin: 0 !important;
    }

    .hw-table th {
        background-color: #f4f6f8 !important;
        color: #333333 !important;
        font-size: 13px !important;
        font-weight: bold !important;
        text-align: center !important;
        vertical-align: middle !important;
        padding: 10px 6px !important;
        border: 1px solid #dee2e6 !important;
    }

    .hw-table td {
        vertical-align: middle !important;
        padding: 6px !important;
        border: 1px solid #dee2e6 !important;
    }

    /* Ép tất cả input và dropdown nằm gọn 100% trong ô */
    .hw-table input, 
    .hw-table select {
        width: 100% !important;
        max-width: 100% !important;
        box-sizing: border-box !important;
        height: 36px !important;
        font-size: 13px !important;
        padding: 4px 8px !important;
        border-radius: 4px !important;
        border: 1px solid #ced4da !important;
    }

    .btn-save {
        background-color: #007bff;
        color: #ffffff;
        border: none;
        border-radius: 4px;
        padding: 10px 38px !important;
        font-size: 15px !important;
        font-weight: bold !important;
        cursor: pointer;
        transition: background-color 0.2s ease;
    }

    .btn-save:hover {
        background-color: #0056b3;
    }

    .diag-pre {
        background: #fdfdfd !important;
        color: #212529 !important;
        border: 1px solid #ced4da !important;
        padding: 15px !important;
        border-radius: 6px !important;
        max-height: 220px !important;
        overflow-y: auto !important;
        font-family: Consolas, "Courier New", monospace !important;
        font-size: 13px !important;
        line-height: 1.5 !important;
        margin: 0 !important;
    }
</style>

<div class="hw-wrapper">
    <div class="hw-box">
        <h3 class="hw-title">Hardware Configuration</h3>
        
        <form method="post" action="hw.php">
            <input type="hidden" name="action" value="submit">
            <div style="width: 100%; overflow: hidden;">
                          <table class="hw-table" style="width: 100%; table-layout: fixed;">
            <thead>
              <tr>
                <th style="width: 25%; text-align: center;">Player Name</th>
                <th style="width: 25%; text-align: center;">Audio Output Device</th>
                <th style="width: 25%; text-align: center;">DSD Output Mode</th>
                <th style="width: 25%; text-align: center;">Max Sample Rate</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td style="padding: 6px; text-align: center;">
                  <input type="text" name="NAME0" value="{$NAME0}" style="width: 95%; box-sizing: border-box;">
                  <input type="hidden" name="MAC0" value="{if $MAC0}{$MAC0}{else}00:04:20:ab:cd:ef{/if}">
                  <input type="hidden" name="NAME1" value="">
                  <input type="hidden" name="MAC1" value="">
                  <input type="hidden" name="DEVICENAME1" value="None">
                  <input type="hidden" name="NAME2" value="">
                  <input type="hidden" name="MAC2" value="">
                  <input type="hidden" name="DEVICENAME2" value="None">
                </td>
                <td style="padding: 6px; text-align: center;">
                  <select name="DEVICENAME0" style="width: 95%; box-sizing: border-box;">
                    {foreach from=$audio_devices key=k item=v}
                      <option value="{$k}" {if $k eq $DEVICENAME0}selected{/if}>{$v}</option>
                    {/foreach}
                  </select>
                </td>
                <td style="padding: 6px; text-align: center;">
                  <select name="DSDMODE0" style="width: 95%; box-sizing: border-box;">
                    {foreach from=$dsd_options key=dk item=dv}
                      <option value="{$dk}" {if $dk eq $DSDMODE0}selected{/if}>{$dv}</option>
                    {/foreach}
                  </select>
                </td>
                <td style="padding: 6px; text-align: center;">
                  <select name="MAXRATE0" style="width: 95%; box-sizing: border-box;">
                    {foreach from=$rate_options key=rk item=rv}
                      <option value="{$rk}" {if $rk eq $MAXRATE0}selected{/if}>{$rv}</option>
                    {/foreach}
                  </select>
                </td>
              </tr>
            </tbody>
          </table>
            </div>

            <div style="margin-top: 25px; text-align: center;">
<!-- MAESTRO REALTIME PITCH SELECTOR -->
<div class="form-group" style="margin: 20px 0; padding: 5px 0;">
    <label for="tuning_freq"><strong>Tuning Frequency:</strong></label>
    <select name="tuning_freq" id="tuning_freq" class="form-control" style="max-width: 420px; font-weight: bold; padding: 6px;">
        <option value="440" {if $current_tuning == "440"}selected{/if}>440 Hz - Standard (Bit-Perfect / Bypass)</option>
        <option value="435" {if $current_tuning == "435"}selected{/if}>435 Hz - Diapason Normal (Vocal / Warm)</option>
        <option value="432" {if $current_tuning == "432"}selected{/if}>432 Hz - Natural (Verdi)</option>
        <option value="430.5" {if $current_tuning == "430.5"}selected{/if}>430.5 Hz - Scientific (C=256 Hz 12-TET)</option>
        <option value="426.6" {if $current_tuning == "426.6"}selected{/if}>426.6 Hz - Pure Harmonic (Just Intonation)</option>
    </select>
    <small style="display:block; color:#777; margin-top:6px;">
        * 440 Hz maintains native Bit-Perfect playback. Alternative tunings apply realtime Hi-Fi DSP.
    </small>
    <span id="pitch_status" style="font-size: 12px; color: #28a745; font-weight: bold; display: none;">{if $action == "submit"}<div style="color: #28a745; font-weight: bold; margin-top: 6px;">✓ Tuning applied successfully!</div>{/if}</span>
</div>
<!-- MAESTRO ALSA BUFFER SELECTOR -->
<div class="form-group" style="margin: 20px 0; padding: 5px 0;">
    <label for="buffer_preset"><strong>ALSA Buffer Preset:</strong></label>
    <select name="buffer_preset" id="buffer_preset" class="form-control" style="max-width: 420px; font-weight: bold; padding: 6px;">
        <option value="tight" {if $current_buffer == 'tight'}selected{/if}>Tight (10ms buffer, ultra-fast)</option>
        <option value="balanced" {if $current_buffer == 'balanced' || !$current_buffer}selected{/if}>Balanced / Standard (Default)</option>
        <option value="relaxed" {if $current_buffer == 'relaxed'}selected{/if}>Relaxed (80ms buffer, warm & smooth)</option>
        <option value="safe" {if $current_buffer == 'safe'}selected{/if}>Safe Mode (160ms buffer, no mmap)</option>
    </select>
    <small style="display:block; color:#777; margin-top:6px;">
        * Adjusts ALSA hardware buffer latency. Select <b>Relaxed</b> or <b>Safe Mode</b> to eliminate digital glare or harshness.
    </small>
</div>

<script>
function updateMaestroPitch(val) {
    fetch('/set_pitch.php?val=' + encodeURIComponent(val))
        .then(response => response.text())
        .then(data => {
            var status = document.getElementById('pitch_status');
            if (status) {
                status.style.display = 'inline-block';
                setTimeout(function() { status.style.display = 'none'; }, 2500);
            }
        });
}

document.addEventListener("DOMContentLoaded", function() {
    fetch('/get_pitch.php')
        .then(response => response.text())
        .then(val => {
            val = val.trim();
            var selectBox = document.getElementById('tuning_freq');
            if (selectBox && val) {
                selectBox.value = val;
            }
        });
});
</script>
<button type="submit" class="btn-save">Save Settings</button>
            </div>
        </form>
    </div>

    <div class="hw-box" style="padding: 20px 25px;">
        <h5 style="color: #495057; font-weight: bold; margin-top: 0; margin-bottom: 12px; font-size: 15px;">ALSA Audio System Diagnostics</h5>
        <pre class="diag-pre">{$CardList}</pre>
    </div>
</div>

{include file="footer.tpl"}
<script id="exact_filter_loopback">
document.addEventListener("DOMContentLoaded", function() {
    document.querySelectorAll('option').forEach(function(opt) {
        if (opt.value === "hw:CARD=Loopback,DEV=0" || opt.text.trim() === "hw:CARD=Loopback,DEV=0") {
            opt.remove();
        }
    });
});
</script>
